const CompressionWebpackPlugin = require('compression-webpack-plugin');

module.exports = {
  publicPath:"/de30f54fd07a43c4ab36d3606de3184e",
  configureWebpack: {
    // devtool
    devtool: 'cheap-module-eval-source-map'
  },
  productionSourceMap: true,
  transpileDependencies: ['element-ui', 'ele-admin', 'vue-i18n'],
  chainWebpack(config) {
    config.plugins.delete('prefetch');
    if (process.env.NODE_ENV !== 'development') {
      // 对超过10kb的文件gzip压缩
      config.plugin('compressionPlugin').use(
        new CompressionWebpackPlugin({
          test: /\.(js|css|html)$/,
          threshold: 10240
        })
      );
    }
  },
  css: {
    loaderOptions: {
      sass: {
        sassOptions: {
          outputStyle: 'expanded'
        }
      }
    }
  }
};
