<!-- 框架布局 -->
<template>
  <ele-pro-layout
    :menus="menus"
    :home-title="homeTitle"
    :project-name="projectName"
    :show-setting.sync="showSetting"
    :need-setting="enableSetting"
    :hide-footers="hideFooters"
    :hide-sidebars="hideSidebars"
    :repeatable-tabs="repeatableTabs"
    :tabs="theme.tabs"
    :color="theme.color"
    :collapse="theme.collapse"
    :head-style="theme.headStyle"
    :side-style="theme.sideStyle"
    :layout-style="theme.layoutStyle"
    :side-menu-style="theme.sideMenuStyle"
    :fixed-body="theme.fixedBody"
    :fixed-header="theme.fixedHeader"
    :fixed-sidebar="theme.fixedSidebar"
    :body-full="theme.bodyFull"
    :show-footer="theme.showFooter"
    :colorful-icon="theme.colorfulIcon"
    :logo-auto-size="theme.logoAutoSize"
    :side-unique-open="theme.sideUniqueOpen"
    :show-tabs="theme.showTabs"
    :tab-style="theme.tabStyle"
    :dark-mode="theme.darkMode"
    :weak-mode="theme.weakMode"
    :i18n="i18n"
    :locale="locale"
    @logo-click="onLogoClick"
    @reload-page="reloadPage"
    @update-screen="updateScreen"
    @update-collapse="updateCollapse"
    @tab-add="tabAdd"
    @tab-remove="tabRemove"
    @tab-remove-all="tabRemoveAll"
    @tab-remove-left="tabRemoveLeft"
    @tab-remove-right="tabRemoveRight"
    @tab-remove-other="tabRemoveOther"
    @change-style="changeStyle"
    @change-color="changeColor"
    @change-dark-mode="changeDarkMode"
    @change-weak-mode="changeWeakMode"
    @set-home-components="setHomeComponents"
    @reset-setting="resetSetting"
  >
    <!-- logo图标 -->
    <template slot="logo">
      <img src="@/assets/logo.svg" alt="logo" />
    </template>
    <!-- 顶栏右侧区域 -->
    <template slot="right">
      <ele-header-right
        :setting="enableSetting"
        :fullscreen="fullscreen"
        @item-click="onItemClick"
        @change-language="changeLanguage"
        @change-fullscreen="changeFullscreen"
      />
    </template>
    <!-- 全局页脚 -->
    <template slot="footer">
      <ele-footer />
    </template>
    <!-- 修改密码弹窗 -->
    <ele-password :visible.sync="showPassword" />
  </ele-pro-layout>
</template>

<script>
  import { mapGetters } from 'vuex';
  import EleHeaderRight from './components/header-right';
  import ElePassword from './components/password';
  import EleFooter from './components/footer';
  import {
    HIDE_SIDEBARS,
    HIDE_FOOTERS,
    REPEATABLE_TABS,
    HOME_TITLE,
    ENABLE_SETTING
  } from '@/config/setting';
  import {
    addPageTab,
    removePageTab,
    removeAllPageTab,
    removeLeftPageTab,
    removeRightPageTab,
    removeOtherPageTab,
    reloadPageTab
  } from '@/utils/page-tab-util';

  export default {
    name: 'EleLayout',
    components: {
      EleHeaderRight,
      ElePassword,
      EleFooter
    },
    data() {
      return {
        // 是否显示修改密码弹窗
        showPassword: false,
        // 是否显示主题设置抽屉
        showSetting: false,
        // 是否是全屏状态
        fullscreen: false,
        // 项目名
        projectName: process.env.VUE_APP_NAME,
        // 顶栏是否显示主题设置按钮
        enableSetting: ENABLE_SETTING,
        // 不显示页脚的路由
        hideFooters: HIDE_FOOTERS,
        // 不显示侧栏的路由
        hideSidebars: HIDE_SIDEBARS,
        // 页签同路由不同参数可重复打开的路由
        repeatableTabs: REPEATABLE_TABS
      };
    },
    computed: {
      // 当前语言
      locale() {
        return this.$i18n.locale;
      },
      // 主页标题
      homeTitle() {
        // 去掉国际化后直接return HOME_TITLE
        return this.$t('layout.home') ?? HOME_TITLE;
      },
      // 菜单数据
      menus() {
        return this.$store.state.user.menus;
      },
      // 主题状态
      ...mapGetters(['theme'])
    },
    methods: {
      /* 顶栏右侧点击 */
      onItemClick(key) {
        if (key === 'password') {
          this.showPassword = true;
        } else if (key === 'setting') {
          this.showSetting = true;
        }
      },
      /* 全屏切换 */
      changeFullscreen() {
        try {
          this.fullscreen = this.$util.toggleFullscreen();
        } catch (e) {
          this.$message.error('您的浏览器不支持全屏模式');
        }
      },
      /* logo点击事件 */
      onLogoClick(isHome) {
        if (!isHome) {
          this.$router.push('/');
        }
      },
      /* 刷新页签 */
      reloadPage() {
        reloadPageTab();
      },
      /* 添加tab */
      tabAdd(value) {
        addPageTab(value);
      },
      /* 移除tab */
      tabRemove(obj) {
        removePageTab(obj.name, obj.active);
      },
      /* 移除全部tab */
      tabRemoveAll(active) {
        removeAllPageTab(active);
      },
      /* 移除左边tab */
      tabRemoveLeft(value) {
        removeLeftPageTab(value);
      },
      /* 移除右边tab */
      tabRemoveRight(value) {
        removeRightPageTab(value);
      },
      /* 移除其它tab */
      tabRemoveOther(value) {
        removeOtherPageTab(value);
      },
      /* 更新collapse */
      updateCollapse(value) {
        this.$store.dispatch('theme/set', { key: 'collapse', value: value });
      },
      /* 更新屏幕尺寸 */
      updateScreen() {
        this.$store.dispatch('theme/updateScreen');
        this.fullscreen = this.$util.isFullscreen();
      },
      /* 重置设置 */
      resetSetting() {
        this.$store.dispatch('theme/resetSetting');
      },
      /* 切换主题风格 */
      changeStyle(value) {
        this.$store.dispatch('theme/set', value);
      },
      /* 切换主题色 */
      changeColor(value) {
        const loading = this.$loading({
          lock: true,
          background: 'transparent'
        });
        this.$store
          .dispatch('theme/setColor', value)
          .then(() => {
            loading.close();
          })
          .catch((e) => {
            console.log(e)
            loading.close();
            this.$message.error('主题加载失败');
          });
      },
      /* 切换暗黑模式 */
      changeDarkMode(value) {
        this.$store.dispatch('theme/setDarkMode', value);
      },
      /* 切换色弱模式 */
      changeWeakMode(value) {
        this.$store.dispatch('theme/setWeakMode', value);
      },
      /* 设置主页包含的组件名称 */
      setHomeComponents(components) {
        this.$store.dispatch('theme/setHomeComponents', components);
      },
      /* 菜单路由国际化对应的名称 */
      i18n(path, key /*, menu*/) {
        // 参数三menu即原始菜单数据, 如果需要菜单标题多语言数据从接口返回可用此参数获取对应的多语言标题
        // 例如下面这样写, 接口的菜单数据为{path: '/system/user', titles: {zh: '用户管理', en: 'User'}}
        // return menu ? menu.titles[this.$i18n.locale] : null;
        const k = 'route.' + key + '._name';
        const title = this.$t(k);
        return title === k ? null : title;
      },
      /* 切换语言 */
      changeLanguage(lang) {
        this.$i18n.locale = lang;
        localStorage.setItem('i18n-lang', lang);
      }
    }
  };
</script>
