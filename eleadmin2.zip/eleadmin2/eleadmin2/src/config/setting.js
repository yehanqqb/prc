// 不显示侧栏的路由
export const HIDE_SIDEBARS = [];

// 不显示页脚的路由
export const HIDE_FOOTERS = [
  '/system/dictionary',
  '/system/organization',
  '/form/advanced',
  '/example/choose'
];

// 页签同路由不同参数可重复打开的路由
export const REPEATABLE_TABS = ['/system/user-info'];

// 不需要登录的路由
export const WHITE_LIST = ['/login', '/forget', '/binding', '/readme/merchant', '/readme/supplier'];

// 直接指定菜单数据
export const USER_MENUS = null;

// token传递的header名称
export const TOKEN_HEADER_NAME = 'Authorization';

// token存储的名称
export const TOKEN_STORE_NAME = 'access_token';

// 主题配置存储的名称
export const THEME_STORE_NAME = 'theme';

// 首页名称, 为空则取第一个菜单的名称
export const HOME_TITLE = '主页';

// 首页路径, 为空则取第一个菜单的地址
export const HOME_PATH = null;

// 顶栏是否显示主题设置按钮
export const ENABLE_SETTING = true;

// 开启多页签后是否缓存组件
export const TAB_KEEP_ALIVE = process.env.NODE_ENV !== 'development';

export const MONEY_TABLE = [10, 20, 30, 50, 100, 200, 300, 500]

export const PROVINCE = ["北京", "天津", "上海", "重庆", "河北", "山西", "辽宁", "吉林", "黑龙江", "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南", "广东", "甘肃", "四川", "贵州", "海南", "云南", "陕西", "广西", "宁夏", "新疆", "内蒙古", "青海", "西藏"]
