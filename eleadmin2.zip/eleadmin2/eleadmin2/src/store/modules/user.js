/**
 * 登录状态管理
 */
import { formatMenus, toTreeData } from 'ele-admin';
import { USER_MENUS } from '@/config/setting';
import { getUserInfo } from '@/api';

export default {
  namespaced: true,
  state: {
    // 当前登录用户信息
    info: null,
    // 当前登录用户的菜单
    menus: null,
    // 当前登录用户的权限
    authorities: [],
    // 当前登录用户的角色
    roles: []
  },
  mutations: {
    // 设置登录用户的信息
    setUserInfo(state, info) {
      state.info = info;
    },
    // 设置登录用户的菜单
    setMenus(state, menus) {
      state.menus = menus;
    },
    // 设置登录用户的权限
    setAuthorities(state, authorities) {
      state.authorities = authorities;
    },
    // 设置登录用户的角色
    setRoles(state, roles) {
      state.roles = roles;
    }
  },
  actions: {
    /**
     * 请求用户信息、权限、角色、菜单
     * @param commit
     * @returns {Promise}
     */
    fetchUserInfo({ commit }) {
      return new Promise((resolve, reject) => {
        getUserInfo()
          .then((result) => {
            // 用户信息
            commit('setUserInfo', result);
            // 用户权限
            const authorities = result.authorities
              ?.filter((d) => !!d.authority)
              ?.map((d) => d.authority);
            commit('setAuthorities', authorities);
            // 用户角色
            const roles = result.roles?.map((d) => d.roleCode);
            commit('setRoles', roles);
            // 用户菜单
            const menuData = toTreeData({
              data: result.authorities?.filter((d) => d.menuType === 0), // 过滤掉按钮类型的菜单
              idField: 'menuId',
              parentIdField: 'parentId'
            });
            // 处理菜单数据格式
            const { menus, homePath } = formatMenus(USER_MENUS ?? menuData);
            commit('setMenus', menus);
            resolve({ menus, homePath });
          })
          .catch((e) => {
            reject(e);
          });
      });
    }
  }
};
