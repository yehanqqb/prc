/**
 * vuex getter
 */
export default {
  user: (state) => state.user,
  theme: (state) => state.theme
};
