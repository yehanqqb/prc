export function getCode(leng) {
  const timeNUM = (new Date().getTime()).toString();
  const c = timeNUM.split("").reverse().join("");
  return c.substr(0, leng);
}

// 公共分页
export function pageParam(where, order, range, title) {
  const result = {};
  for (const key in where) {
    if (where[key] === '' || where[key] === null) {
      delete where[key];
    }
  }
  result['common'] = where;
  // sort[{name:'',desc:true}] 排序
  // range[{name:'',start:'',end:''}] 范围筛选
  // common{} 精确搜索
  // dim{} 模糊搜索
  result['sort'] = Array();
  result['range'] = Array();
  result['sort'].push({column: "create_time", asc: false})
  // [{name:'',value:'',type:'COUNT'}] type="NUM" 相加 ="COUNT" 计数
  result['titleCount'] = title;
  if (!isNull(range)) {
    result['range'] = range;
  }
  return result;
}

export function getDayTime() {
  let startTime1 = new Date(new Date(new Date().toLocaleDateString()).getTime()); // 当天0点
  let endTime1 = new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1);// 当天23:59
  return [startTime1, endTime1];
}

export function getDayTimeByDate(date) {
  let startTime1 = new Date(new Date(date.toLocaleDateString()).getTime()); // 当天0点
  let endTime1 = new Date(new Date(date.toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1);// 当天23:59
  return [startTime1, endTime1];
}

export function isNull(val) {
  return val === null || val === undefined || val === "" || JSON.stringify(val) === '{}'
}
