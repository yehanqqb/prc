/**
 * axios实例
 */
import axios from 'axios';
import router from '@/router';
import {MessageBox, Message} from 'element-ui';
import {TOKEN_HEADER_NAME} from '@/config/setting';
import {getToken, setToken, removeToken} from './token-util';

const service = axios.create({
  baseURL: process.env.VUE_APP_API_BASE_URL
});

/* 跳转到登录页面 */
const goLogin = function (from) {
  removeToken();
  router.push({
    path: '/login',
    query: from ? {from} : undefined
  });
};

/* 添加请求拦截器 */
service.interceptors.request.use(
  (config) => {
    // 添加token到header
    const token = getToken();
    if (token && config.headers && !config.url.includes("/login/bind")) {
      config.headers.common[TOKEN_HEADER_NAME] = token;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

/* 添加响应拦截器 */
service.interceptors.response.use((res) => {
    // 登录过期处理
    if (res.data?.code === 401 || res.data?.code === 403) {
      const currentPath = router.currentRoute.path;
      if (currentPath === '/') {
        goLogin();
      } else {
        MessageBox.alert('登录状态已过期, 请退出重新登录!', '系统提示', {
          confirmButtonText: '重新登录',
          callback: (action) => {
            if (action === 'confirm') {
              goLogin(currentPath);
            }
          },
          beforeClose: () => {
            MessageBox.close();
          }
        });
      }
      return Promise.reject(new Error(res.data.message));
    }
    // token自动续期
    const token = res.headers[TOKEN_HEADER_NAME.toLowerCase()];
    if (token) {
      setToken(token);
    }
    return res;
  },
  (error) => {
    if (error.response.status === 403 || error.response.status === 401) {
      goLogin();
    }
    if (error.response.status === 500) {
      console.log(error.response.data.message);
      const message = error.response.data.message;
      Message({
        type: 'error',
        message,
      })
    }
  }
);

export default service;
