import axios from '@/utils/request';

export async function getQr(idp) {
  const res = await axios.get('/tenant/ail/shop/getQr?idp=' + idp);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function checkQr(idp) {
  const res = await axios.post('/tenant/ail/shop/checkQr?idp=' + idp);
  return res.data;
}

export async function checkSms(idp, code) {
  const res = await axios.post('/tenant/ail/shop/checkSms?idp=' + idp + "&code=" + code);
  return res.data;
}

export async function saveOrUpdateShop(data) {
  const res = await axios.post('/tenant/ail/shop/shop?idp=' + data.idp + "&name=" + data.name + "&id=" + data.id);
  if (res.data.code === 200) {
    return res.data;
  }
  return Promise.reject(new Error(res.data.msg));
}


export async function pageList(data) {
  const res = await axios.post('/tenant/ail/shop/page', data);
  if (res.data.code === 200) {
    return {
      list: res.data.data.data, count: res.data.data.count
    };
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function saveOrUpdateGoods(data) {
  const res = await axios.put('/tenant/ail/shop/goods', data);
  if (res.data.code === 200) {
    return res.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function saveOrStatus(id, status) {
  const res = await axios.put('/tenant/ail/shop/shop/' + id + "?status=" + status);
  if (res.data.code === 200) {
    return res.data;
  }
  return Promise.reject(new Error(res.data.msg));
}
