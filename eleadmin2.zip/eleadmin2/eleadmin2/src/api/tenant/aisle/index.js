import axios from '@/utils/request';

export async function pageList(data) {
  const res = await axios.post('/tenant/aisle/page', data);
  if (res.data.code === 200) {
    return {
      list: res.data.data.data, count: res.data.data.count
    };
  }
  return Promise.reject(new Error(res.data.msg));
}


export async function getSupplier(aisleId) {
  const res = await axios.post('/tenant/aisle/supplier/' + aisleId);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function saveRadioApi(data) {
  const res = await axios.post('/tenant/aisle/save/supplier', data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function saveOrUpdate(data) {
  const res = await axios.post('/tenant/aisle/save', data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function deleteById(id) {
  const res = await axios.delete('/tenant/aisle/supplier/' + id);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}
