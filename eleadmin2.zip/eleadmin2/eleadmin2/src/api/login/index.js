import axios from '@/utils/request';
import {getToken, setToken} from '@/utils/token-util';

/**
 * 登录
 */
export async function login(data) {
  const res = await axios.post('/login/login', data);
  if (res.data.code === 200) {
    setToken(res.data.data.token, true);
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

/**
 * 获取验证码
 */
export async function getCaptcha(clientId) {
  const res = await axios.get('/login/kapt/' + clientId);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.message));
}

/**
 * 获取验证码
 */
export async function bindGoogle(code) {
  const res = await axios.post('/login/bind?code=' + code + "&token=" + getToken());
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.message));
}
