import axios from '@/utils/request';

export async function pageList(data) {
  const res = await axios.post('/manager/tenant/page', data);
  if (res.data.code === 200) {
    return {
      list: res.data.data.data, count: res.data.data.count
    };
  }
  return Promise.reject(new Error(res.data.msg));
}


export async function save(data) {
  const res = await axios.post('/manager/tenant', data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function update(tenantId, data) {
  const res = await axios.put('/manager/tenant/' + tenantId, data);
  if (res.data.code === 200) {
    return saveAisle(tenantId, {ids: data.aisles});
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function saveAisle(tenantId, data) {
  const res = await axios.put('/manager/tenant/aisle/' + tenantId, data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

