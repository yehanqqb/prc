import axios from "@/utils/request";




/**
 * 获取条形图
 */
export async function queryBarList(tenantId,slow) {
  const res = await axios.get(
    `/manager/home/repertory/` + tenantId+'/'+slow,
  );
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.message));
}

/**
 * 获取进度图
 */
export async function queryProcessList(tenantId, params) {
  const res = await axios.post(
    `/manager/home/money/` + tenantId,
    params
  );
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.message));
}

/**
 * 获取统计卡片
 */
export async function queryCardList(tenantId, params) {
  const res = await axios.post(
    `/manager/home/stage/` + tenantId, params);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.message));
}

