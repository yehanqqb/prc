import axios from '@/utils/request';

export async function get() {
  const res = await axios.get('/manager/gateway');
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}


export async function saveOrUpdate(data) {
  const res = await axios.post('/manager/gateway', {route: data});
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}
