import axios from '@/utils/request';

export async function pageList(data) {
  data["page"] = 1;
  data["limit"] = 1000;
  const res = await axios.post('/manager/menu/page', data);
  if (res.data.code === 200) {
    return res.data.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}


export async function saveOrUpdate(data) {
  const res = await axios.post('/manager/menu', data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}
