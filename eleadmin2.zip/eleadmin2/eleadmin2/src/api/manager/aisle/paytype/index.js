import axios from '@/utils/request';

export async function pageList(data) {
  const res = await axios.post('/manager/payType/page', data);
  if (res.data.code === 200) {
    return {
      list: res.data.data.data, count: res.data.data.count
    };
  }
  return Promise.reject(new Error(res.data.msg));
}


export async function saveOrUpdate(data) {
  const res = await axios.post('/manager/payType', data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}
