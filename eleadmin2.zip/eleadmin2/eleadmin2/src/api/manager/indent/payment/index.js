import axios from '@/utils/request';

export async function pageList(data) {
  const res = await axios.post('/manager/payment-order/page', data);
  if (res.data.code === 200) {
    return {
      list: res.data.data.data, count: res.data.data.count
    };
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function getTitle(data) {
  const res = await axios.post('/manager/payment-order/title', data);
  if (res.data.code === 200) {
    return res.data.data
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function reissue(data) {
  const res = await axios.post('/manager/payment-order/reissue', data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function look(data) {
  const res = await axios.post('/manager/payment-order/look/' + data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}
