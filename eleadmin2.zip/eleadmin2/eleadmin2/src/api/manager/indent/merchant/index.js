import axios from '@/utils/request';

export async function pageList(data) {
  const res = await axios.post('/manager/merchant-order/page', data);
  if (res.data.code === 200) {
    return {
      list: res.data.data.data, count: res.data.data.count
    };
  }
  return Promise.reject(new Error(res.data.msg));
}

export async function getTitle(data) {
  const res = await axios.post('/manager/merchant-order/title', data);
  if (res.data.code === 200) {
    return res.data.data
  }
  return Promise.reject(new Error(res.data.msg));
}


export async function saveOrUpdate(data) {
  const res = await axios.post('/manager/merchant-order', data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}


export async function reissue(data) {
  const res = await axios.post('/manager/merchant-order/reissue', data);
  if (res.data.code === 200) {
    return res.data.data;
  }
  return Promise.reject(new Error(res.data.msg));
}
