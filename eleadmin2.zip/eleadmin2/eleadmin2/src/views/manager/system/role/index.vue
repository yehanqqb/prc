<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <role-search @search="reload"/>
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >
        <!-- 状态列 -->
        <template slot="status" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.status"
            @change="editStatus(row)"
          />
        </template>
        <template slot="authority" slot-scope="{ row }">
          <el-select v-model="row.authority" disabled multiple placeholder="请选择">
            <el-option
              v-for="item in row.authority"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-plus"
            class="ele-btn-icon"
            @click="openEdit()"
          >
            添加
          </el-button>
        </template>
        <!-- 操作列 -->
        <template slot="action" slot-scope="{ row }">
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openEdit(row)"
          >
            修改
          </el-link>
        </template>
      </ele-pro-table>
    </el-card>
    <role-edit :data="current" :visible.sync="showEdit" @done="reload"/>
  </div>
</template>

<script>
import RoleSearch from './components/role-search';
import RoleEdit from './components/role-edit';
import {pageList, saveOrUpdate} from '@/api/manager/system/role';
import {pageParam} from "@/utils/application";

export default {
  name: 'SystemRole',
  components: {
    RoleSearch,
    RoleEdit
  },
  data() {
    return {
      // 表格列配置
      columns: [
        {
          columnKey: 'selection',
          type: 'selection',
          width: 45,
          align: 'center'
        },
        {
          columnKey: 'index',
          type: 'index',
          width: 45,
          align: 'center',
          showOverflowTooltip: true
        },
        {
          prop: 'name',
          label: '角色名称',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 45
        },
        {
          prop: 'roleKey',
          label: '角色标识',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 45
        },
        {
          prop: 'sort',
          label: '顺序',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 45
        },
        {
          prop: 'status',
          label: '开启',
          align: 'center',
          sortable: 'custom',
          width: 150,
          resizable: false,
          slot: 'status'
        },
        {
          prop: 'authority',
          label: '权限',
          align: 'center',
          sortable: 'custom',
          width: 200,
          resizable: false,
          slot: 'authority'
        },
        {
          prop: 'createTime',
          label: '创建时间',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 110,
          formatter: (row, column, cellValue) => {
            return this.$util.toDateString(cellValue);
          }
        },
        {
          columnKey: 'action',
          label: '操作',
          width: 230,
          align: 'center',
          resizable: false,
          slot: 'action'
        }
      ],
      // 表格选中数据
      selection: [],
      // 当前编辑数据
      current: null,
      // 是否显示编辑弹窗
      showEdit: false,
      // 是否显示导入弹窗
      showAuth: false
    };
  },
  methods: {
    /* 表格数据源 */
    datasource({page, limit, where, order}) {
      const common = {
        name: where.name,
        roleKey: where.roleKey,
      };
      const range = []
      const params = pageParam(common, order, range)
      return pageList({...params, page, limit});
    },
    /* 刷新表格 */
    reload(where) {
      this.$refs.table.reload({page: 1, where: where});
    },
    /* 显示编辑 */
    openEdit(row) {
      this.current = row;
      this.showEdit = true;
    },
    /* 更改状态 */
    editStatus(row) {
      const loading = this.$loading({lock: true});
      saveOrUpdate(row)
        .then((msg) => {
          loading.close();
          this.$message.success(msg);
        })
        .catch((e) => {
          loading.close();
          this.$message.error(e.message);
        });
    },
  }
};
</script>

<style scoped></style>
