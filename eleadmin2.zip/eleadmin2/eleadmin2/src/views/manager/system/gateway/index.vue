<template>
  <div class="ele-body">
    <el-button type="primary" @click="edit()">新增</el-button>
    <el-table
      :data="tableData"
      border
      size="medium"
      style="width: 100%">
      <el-table-column
        prop="id"
        label="服务"
        width="180">
      </el-table-column>
      <el-table-column
        prop="uri"
        label="链接"
        width="180">
      </el-table-column>
      <el-table-column
        label="操作"
        width="100">
        <template slot-scope="scope">
          <el-button @click="remove(scope)" type="text" size="small">删除</el-button>
          <el-button @click="edit(scope)" type="text" size="small">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog
      :visible="visable"
      :close-on-click-modal="false"
      custom-class="ele-dialog-form"
      :title="current.id ? '修改' : '新增'"
    >
      <el-row :gutter="15">
        <el-form ref="form" :model="current" label-width="82px">
          <el-form-item label="id:">
            <el-input v-model="current.id"></el-input>
          </el-form-item>
          <el-form-item label="uri:">
            <el-input v-model="current.uri"></el-input>
          </el-form-item>
        </el-form>
      </el-row>
      <div slot="footer">
        <el-button @click="updateVisible(false)">取消</el-button>
        <el-button type="primary" @click="save" :loading="loading">
          保存
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {get} from "@/api/manager/system/gateway";
import {saveOrUpdate} from "@/api/manager/system/gateway";

export default {
  name: 'gateway',
  data() {
    return {
      tableData: [],
      visable: false,
      current: {},
      loading: false,
    };
  },
  created() {
    get().then(res => {
      this.tableData = res;
    })
  },

  methods: {
    remove(row) {
      let array = [];
      for (let i = 0; i < this.tableData.length; i++) {
        if (i !== row.$index) {
          array.push(this.tableData[row.$index]);
        }
      }
      this.tableData = array;
      saveOrUpdate(this.tableData)
        .then((msg) => {
          this.loading = false;
          this.$message.success(msg);
          this.updateVisible(false);
          this.$emit('done');
        })
        .catch((e) => {
          this.loading = false;
          this.$message.error(e.message);
        });
    },
    edit(scope) {
      if (scope !== null && scope !== undefined) {
        this.current = scope.row;
      }
      this.updateVisible(true);
    },
    updateVisible(status) {
      if (!status) {
        this.current = {}
      }
      this.visable = status;
    },
    /* 保存编辑 */
    save() {
      this.loading = true;
      let array = [];
      let add = true;
      for (let i = 0; i < this.tableData.length; i++) {
        if (this.tableData[i].id === this.current.id) {
          add = false;
          array.push(this.current);
        } else {
          array.push(this.tableData[i]);
        }
      }
      if (add) {
        let template = {
          "id": this.current.id,
          "order": 1,
          "predicates": [
            {
              "args": {
                "_genkey_0": "/" + this.current.id + "/**"
              },
              "name": "Path"
            }
          ],
          "uri": this.current.uri,
          "filters": [
            {
              "args": {
                "_genkey_0": "1"
              },
              "name": "StripPrefix"
            }
          ]
        }
        array.push(template);
      }
      this.tableData = array;
      saveOrUpdate(this.tableData)
        .then((msg) => {
          this.loading = false;
          this.$message.success(msg);
          this.updateVisible(false);
          this.$emit('done');
        })
        .catch((e) => {
          this.loading = false;
          this.$message.error(e.message);
        });
    },
  }
};
</script>

<style scoped></style>
