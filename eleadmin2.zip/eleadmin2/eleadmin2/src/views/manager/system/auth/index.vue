<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <auth-search @search="reload"/>
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >
        <!-- 状态列 -->
        <template slot="hide" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.hide"
            @change="editHide(row)"
          />
        </template>
        <template slot="hasRole" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.hasRole"
            @change="editHasRole(row)"
          />
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-plus"
            class="ele-btn-icon"
            @click="openEdit()"
          >
            添加
          </el-button>
        </template>
        <!-- 操作列 -->
        <template slot="action" slot-scope="{ row }">
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openEdit(row)"
          >
            修改
          </el-link>
        </template>
      </ele-pro-table>
    </el-card>
    <auth-edit :data="current" :visible.sync="showEdit" @done="reload" />
  </div>
</template>

<script>
import AuthSearch from './components/auth-search';
import AuthEdit from './components/auth-edit';
import {pageList, saveOrUpdate} from '@/api/manager/system/auth';
import {pageParam} from "@/utils/application";

export default {
  name: 'SystemAuth',
  components: {
    AuthSearch,
    AuthEdit
  },
  data() {
    return {
      // 表格列配置
      columns: [
        {
          columnKey: 'selection',
          type: 'selection',
          width: 45,
          align: 'center'
        },
        {
          columnKey: 'index',
          type: 'index',
          width: 45,
          align: 'center',
          showOverflowTooltip: true
        },
        {
          prop: 'name',
          label: '权限名称',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 45
        },
        {
          prop: 'authority',
          label: '权限标识',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 45
        },
        {
          prop: 'sort',
          label: '顺序',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 45
        },
        {
          prop: 'hide',
          label: '隐藏',
          align: 'center',
          sortable: 'custom',
          width: 100,
          resizable: false,
          slot: 'hide'
        },
        {
          prop: 'hasRole',
          label: '是否角色',
          align: 'center',
          sortable: 'custom',
          width: 120,
          resizable: false,
          slot: 'hasRole'
        },
        {
          prop: 'createTime',
          label: '创建时间',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 110,
          formatter: (row, column, cellValue) => {
            return this.$util.toDateString(cellValue);
          }
        },
        {
          columnKey: 'action',
          label: '操作',
          width: 230,
          align: 'center',
          resizable: false,
          slot: 'action'
        }
      ],
      // 表格选中数据
      selection: [],
      // 当前编辑数据
      current: null,
      // 是否显示编辑弹窗
      showEdit: false,
      // 是否显示导入弹窗
      showAuth: false
    };
  },
  methods: {
    /* 表格数据源 */
    datasource({page, limit, where, order}) {
      const common = {
        name: where.name,
        authority: where.authority,
      };
      const range = []
      console.log(where.createTime);
      const params = pageParam(common, order, range)
      return pageList({...params, page, limit});
    },
    /* 刷新表格 */
    reload(where) {
      this.$refs.table.reload({page: 1, where: where});
    },
    /* 显示编辑 */
    openEdit(row) {
      this.current = row;
      this.showEdit = true;
    },
    /* 更改状态 */
    editHide(row) {
      const loading = this.$loading({lock: true});
      saveOrUpdate(row)
        .then((msg) => {
          loading.close();
          this.$message.success(msg);
        })
        .catch((e) => {
          loading.close();
          this.$message.error(e.message);
        });
    },
    /* 更改状态 */
    editHasRole(row) {
      const loading = this.$loading({lock: true});
      saveOrUpdate(row)
        .then((msg) => {
          loading.close();
          this.$message.success(msg);
        })
        .catch((e) => {
          loading.close();
          this.$message.error(e.message);
        });
    }
  }
};
</script>

<style scoped></style>
