<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <tenant-search @search="reload"/>
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >
        <!-- 状态列 -->
        <template slot="status" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.isUser.status"
            @change="editStatus(row)"
          />
        </template>
        <template slot="auth" slot-scope="{ row }">
          <el-select v-model="row.isUser.authority" disabled multiple placeholder="请选择">
            <el-option
              v-for="item in row.isUser.authority"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-plus"
            class="ele-btn-icon"
            @click="openEdit()"
          >
            添加
          </el-button>
        </template>
        <!-- 操作列 -->
        <template slot="action" slot-scope="{ row }">
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openEdit(row)"
          >
            修改
          </el-link>
        </template>
      </ele-pro-table>
    </el-card>
    <tenant-edit :data="current" :visible.sync="showEdit" @done="reload"/>
  </div>
</template>

<script>
import TenantSearch from './components/tenant-search';
import TenantEdit from './components/tenant-edit';
import {pageList, update} from '@/api/manager/user/tenant';
import {pageParam} from "@/utils/application";

export default {
  name: 'SystemAuth',
  components: {
    TenantSearch,
    TenantEdit
  },
  data() {
    return {
      // 表格列配置
      columns: [
        {
          columnKey: 'selection',
          type: 'selection',
          width: 45,
          align: 'center'
        },
        {
          columnKey: 'index',
          type: 'index',
          width: 45,
          align: 'center',
          showOverflowTooltip: true
        },
        {
          prop: 'itenant.id',
          label: '租户id',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 45
        },
        {
          prop: 'isUser.username',
          label: '用户名',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 45
        },
        {
          prop: 'isUser.authority',
          label: '其他权限',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 120,
          slot: "auth"
        },
        {
          prop: 'itenant.secret',
          label: '密钥',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150
        },
        {
          prop: 'isUser.status',
          label: '是否禁用',
          align: 'center',
          sortable: 'custom',
          width: 120,
          resizable: false,
          slot: 'status'
        },
        {
          prop: 'isUser.createTime',
          label: '创建时间',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 110,
          formatter: (row, column, cellValue) => {
            return this.$util.toDateString(cellValue);
          }
        },
        {
          columnKey: 'action',
          label: '操作',
          width: 230,
          align: 'center',
          resizable: false,
          slot: 'action'
        }
      ],
      // 表格选中数据
      selection: [],
      // 当前编辑数据
      current: null,
      // 是否显示编辑弹窗
      showEdit: false,
      // 是否显示导入弹窗
      showAuth: false
    };
  },
  methods: {
    /* 表格数据源 */
    datasource({page, limit, where, order}) {
      const common = {
        name: where.name,
      };
      const range = []
      const params = pageParam(common, order, range)
      return pageList({...params, page, limit});
    },
    /* 刷新表格 */
    reload(where) {
      this.$refs.table.reload({page: 1, where: where});
    },
    /* 显示编辑 */
    openEdit(row) {
      if (row !== null && row !== undefined) {
        let up = {};
        up.tenantId = row.itenant.id;
        up.userId = row.isUser.id;
        up.authorityIds = row.isUser.authority;
        up.secret = row.itenant.secret;
        up.status = row.isUser.status;
        up.username = row.isUser.username;
        let aisleIds = [];
        for (let i = 0; i < row.itenantAisleLists.length; i++) {
          aisleIds.push(row.itenantAisleLists[i].isAisle.id);
        }
        up.aisles = aisleIds
        this.current = up;
      }
      this.showEdit = true;
    },
    /* 更改状态 */
    editStatus(row) {
      const loading = this.$loading({lock: true});
      let up = {};
      up.tenantId = row.itenant.id;
      up.userId = row.isUser.id;
      up.authorityIds = row.isUser.authority;
      up.secret = row.itenant.secret;
      up.status = row.isUser.status;
      update(row.itenant.id, up)
        .then((msg) => {
          loading.close();
          this.$message.success(msg);
        })
        .catch((e) => {
          loading.close();
          this.$message.error(e.message);
        });
    }
  }
};
</script>

<style scoped></style>
