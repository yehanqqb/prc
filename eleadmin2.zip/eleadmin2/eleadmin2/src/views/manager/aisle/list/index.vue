<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <aisle-search @search="reload"/>
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >

        <template slot="beforeSlot" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.before"
            disabled
          />
        </template>
        <template slot="status" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.status"
            disabled
          />
        </template>
        <template slot="operators" slot-scope="{ row }">
          <el-select v-model="row.operators" disabled multiple placeholder="请选择" @change="$forceUpdate()">
            <el-option
              v-for="item in operatorsAll"
              :key="item.id"
              :label="item.value"
              :value="item.id">
            </el-option>
          </el-select>
        </template>
        <template slot="payType" slot-scope="{ row }">
          <el-select v-model="row.payType" disabled multiple placeholder="请选择" @change="$forceUpdate()">
            <el-option
              v-for="item in row.payType"
              :key="item"
              :label="item"
              :value="item">
            </el-option>
          </el-select>
        </template>
        <template slot="money" slot-scope="{ row }">
          <el-select v-model="row.rechargeMoney" disabled multiple placeholder="请选择" @change="$forceUpdate()">
            <el-option
              v-for="item in row.rechargeMoney"
              :key="item"
              :label="item"
              :value="item">
            </el-option>
          </el-select>
        </template>
        <template slot="slow" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.slow"
            disabled
          />
        </template>
        <template slot="fix" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.fix"
            disabled
          />
        </template>
        <template slot="primary" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.primary"
            disabled
          />
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-plus"
            class="ele-btn-icon"
            @click="openEdit()"
          >
            添加
          </el-button>
        </template>
        <!-- 操作列 -->
        <template slot="action" slot-scope="{ row }">
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openEdit(row)"
          >
            修改
          </el-link>
        </template>
      </ele-pro-table>
    </el-card>
    <aisle-edit :data="current" :visible.sync="showEdit" @done="reload"/>
  </div>
</template>

<script>
import aisleSearch from './components/aisle-search';
import aisleEdit from './components/aisle-edit';
import {pageList} from '@/api/manager/aisle/list';
import {pageParam} from "@/utils/application";

export default {
  name: 'SystemAisle',
  components: {
    aisleSearch,
    aisleEdit
  },
  data() {
    return {
      // 表格列配置
      columns: [
        {
          columnKey: 'selection',
          type: 'selection',
          width: 45,
          align: 'center'
        },
        {
          columnKey: 'index',
          type: 'index',
          width: 45,
          align: 'center',
          showOverflowTooltip: true
        },
        {
          prop: 'name',
          label: '通道名称',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150
        },
        {
          prop: 'before',
          label: '是否预产',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150,
          slot: "beforeSlot"
        },
        {
          prop: 'payBeanName',
          label: '支付bean',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150
        },
        {
          prop: 'status',
          label: '状态',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 120,
          slot: "status"
        },
        {
          prop: 'operators',
          label: '运行商',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150,
          slot: "operators"
        },
        {
          prop: 'rechargeMoney',
          label: '金额',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150,
          slot: "money"
        },
        {
          prop: 'slow',
          label: '是否慢充',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150,
          slot: "slow"
        },
        {
          prop: 'payType',
          label: '支付编码',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150,
          slot: "payType"
        },
        {
          prop: 'fix',
          label: '任意金额',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150,
          slot: "fix"
        },
        {
          prop: 'primary',
          label: '主监控',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150,
          slot: "primary"
        },
        {
          prop: 'createTime',
          label: '创建时间',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 110,
          formatter: (row, column, cellValue) => {
            return this.$util.toDateString(cellValue);
          }
        },
        {
          columnKey: 'action',
          label: '操作',
          width: 230,
          align: 'center',
          resizable: false,
          slot: 'action'
        }
      ],
      // 表格选中数据
      selection: [],
      // 当前编辑数据
      current: null,
      // 是否显示编辑弹窗
      showEdit: false,
      // 是否显示导入弹窗
      showAuth: false,
      operatorsAll: [
        {id: 0, key: "DX", value: "电信"},
        {id: 1, key: "LT", value: "联通"},
        {id: 2, key: "YD", value: "移动"},
        {id: 3, key: "OTHER", value: "自由金额"},
      ],
    };
  },
  methods: {
    /* 表格数据源 */
    datasource({page, limit, where, order}) {
      const common = {
        name: where.name,
      };
      const range = []
      const params = pageParam(common, order, range)
      return pageList({...params, page, limit});
    },
    /* 刷新表格 */
    reload(where) {
      this.$refs.table.reload({page: 1, where: where});
    },
    /* 显示编辑 */
    openEdit(row) {
      this.current = row;
      this.showEdit = true;
    }
  }
};
</script>

<style scoped></style>
