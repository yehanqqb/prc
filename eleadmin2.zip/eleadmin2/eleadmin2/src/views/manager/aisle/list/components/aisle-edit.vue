<!-- 角色编辑弹窗 -->
<template>
  <el-dialog
    width="900px"
    :visible="visible"
    :close-on-click-modal="false"
    :title="isUpdate ? '修改通道' : '添加通道'"
    @update:visible="updateVisible"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row :gutter="15">
        <el-col :lg="12" :md="24">
          <el-form-item label="name:" prop="name">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
          <el-form-item label="是否预产:" prop="before">
            <el-switch
              :active-value="true"
              :inactive-value="false"
              v-model="form.before"
            />
          </el-form-item>
          <el-form-item label="预产bean:" prop="beforeBeanName" v-if="form.before">
            <el-input v-model="form.beforeBeanName"></el-input>
          </el-form-item>
          <el-form-item label="支付bean:" prop="payBeanName">
            <el-input v-model="form.payBeanName"></el-input>
          </el-form-item>
          <el-form-item label="监控bean:" prop="monitorBean">
            <el-input v-model="form.monitorBean"></el-input>
          </el-form-item>
          <el-form-item label="status:" prop="status">
            <el-switch
              :active-value="true"
              :inactive-value="false"
              v-model="form.status"
            />
          </el-form-item>
          <el-form-item label="运行商:" prop="operators">
            <el-select v-model="form.operators" multiple placeholder="请选择" @change="$forceUpdate()">
              <el-option
                v-for="item in operatorsAll"
                :key="item.id"
                :label="item.value"
                :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="金额:" prop="rechargeMoney">

            <el-select v-model="form.rechargeMoney" multiple placeholder="请选择" @change="$forceUpdate()">
              <el-option
                v-for="item in money"
                :key="item"
                :label="item"
                :value="item">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :lg="12" :md="24">
          <el-form-item label="是否慢充:" prop="slow">
            <el-switch
              :active-value="true"
              :inactive-value="false"
              v-model="form.slow"
            />
          </el-form-item>
          <el-form-item label="未拉起退回时间:" prop="bankLong" v-if="form.slow===false">
            <el-input type="number" v-model="form.bankLong"></el-input>
          </el-form-item>
          <el-form-item label="支付编码:" prop="payType">
            <el-select v-model="form.payType" multiple placeholder="请选择" @change="$forceUpdate()">
              <el-option
                v-for="item in payTypeAll"
                :key="item.payKey"
                :label="item.payKey"
                :value="item.payKey">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="监控时间:" prop="monitoringLong">
            <el-input v-model="form.monitoringLong" type="number"></el-input>
          </el-form-item>
          <el-form-item label="监控休眠:" prop="mountSleep">
            <el-input v-model="form.mountSleep" type="number"></el-input>
          </el-form-item>
          <el-form-item label="是否任意金额:" prop="fix">
            <el-switch
              :active-value="true"
              :inactive-value="false"
              v-model="form.fix"
            />
          </el-form-item>
          <el-form-item label="主监控:" prop="primary">
            <el-switch
              :active-value="true"
              :inactive-value="false"
              v-model="form.primary"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer">
      <el-button @click="updateVisible(false)">取消</el-button>
      <el-button type="primary" @click="save" :loading="loading">
        保存
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {saveOrUpdate} from "@/api/manager/aisle/list";
  import {pageList} from "@/api/manager/aisle/paytype";

  import {MONEY_TABLE} from "@/config/setting";

  const DEFAULT_FORM = {
    id: "",
    name: "",
    before: false,
    beforeBeanName: "",
    payBeanName: "",
    monitorBean: "",
    status: false,
    operators: [],
    rechargeMoney: [],
    slow: false,
    payType: [],
    monitoringLong: "",
    mountSleep: "",
    fix: false,
    primary: true,
    createTime: "",
    bankLong:100
  };

  export default {
    name: 'aisleEdit',
    props: {
      // 弹窗是否打开
      visible: Boolean,
      // 修改回显的数据
      data: Object
    },
    data() {
      return {
        // 表单数据
        form: {...DEFAULT_FORM},
        // 表单验证规则
        rules: {},
        // 提交状态
        loading: false,
        // 是否是修改
        isUpdate: false,
        operatorsAll: [
          {id: 0, key: "DX", value: "电信"},
          {id: 1, key: "LT", value: "联通"},
          {id: 2, key: "YD", value: "移动"},
          {id: 3, key: "OTHER", value: "自由金额"},
        ],
        payTypeAll: [],
        money: []
      };
    },
    created() {
      let query = {};
      query['page'] = 1;
      query['limit'] = 1000;
      pageList(query).then(res => {
        let array = [];
        for (let i = 0; i < res.list.length; i++) {
          if (!res.list[i].status) {
            array.push(res.list[i]);
          }
        }
        this.payTypeAll = array
      })
      this.money = MONEY_TABLE;
    },
    methods: {
      /* 保存编辑 */
      save() {
        this.$refs['form'].validate((valid) => {
          if (!valid) {
            return false;
          }
          this.loading = true;
          saveOrUpdate(this.form)
            .then((msg) => {
              this.loading = false;
              this.$message.success(msg);
              this.updateVisible(false);
              this.$emit('done');
            })
            .catch((e) => {
              this.loading = false;
              this.$message.error(e.message);
            });
        });
      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visible', value);
      }
    },
    watch: {
      visible(visible) {
        if (visible) {
          if (this.data) {
            this.$util.assignObject(this.form, this.data);
            this.isUpdate = true;
          } else {
            this.isUpdate = false;
          }
        } else {
          this.$refs['form'].clearValidate();
          this.form = {...DEFAULT_FORM};
        }
      }
    }
  };
</script>

<style scoped></style>
