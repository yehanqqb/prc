<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <aisle-search @search="reload"/>
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >

        <template slot="status" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.status"
            disabled
          />
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-plus"
            class="ele-btn-icon"
            @click="openEdit()"
          >
            添加
          </el-button>
        </template>
        <!-- 操作列 -->
        <template slot="action" slot-scope="{ row }">
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openEdit(row)"
          >
            修改
          </el-link>
        </template>
      </ele-pro-table>
    </el-card>
    <aisle-edit :data="current" :visible.sync="showEdit" @done="reload"/>
  </div>
</template>

<script>
import aisleSearch from './components/voucher-search';
import aisleEdit from './components/voucher-edit';
import {pageList} from '@/api/manager/aisle/voucher';
import {pageParam} from "@/utils/application";

export default {
  name: 'SystemAisle',
  components: {
    aisleSearch,
    aisleEdit
  },
  data() {
    return {
      // 表格列配置
      columns: [
        {
          columnKey: 'selection',
          type: 'selection',
          width: 45,
          align: 'center'
        },
        {
          columnKey: 'index',
          type: 'index',
          width: 45,
          align: 'center',
          showOverflowTooltip: true
        },
        {
          prop: 'vname',
          label: '名称',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150
        },
        {
          prop: 'vurl',
          label: '地址',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 150,
        },
        {
          prop: 'status',
          label: '状态',
          sortable: 'custom',
          showOverflowTooltip: true,
          minWidth: 120,
          slot: "status"
        },
        {
          columnKey: 'action',
          label: '操作',
          width: 230,
          align: 'center',
          resizable: false,
          slot: 'action'
        }
      ],
      // 表格选中数据
      selection: [],
      // 当前编辑数据
      current: null,
      // 是否显示编辑弹窗
      showEdit: false,
      // 是否显示导入弹窗
      showAuth: false
    };
  },
  methods: {
    /* 表格数据源 */
    datasource({page, limit, where, order}) {
      const common = {
        vname: where.vname,
      };
      const range = []
      const params = pageParam(common, order, range)
      return pageList({...params, page, limit});
    },
    /* 刷新表格 */
    reload(where) {
      this.$refs.table.reload({page: 1, where: where});
    },
    /* 显示编辑 */
    openEdit(row) {
      this.current = row;
      this.showEdit = true;
    }
  }
};
</script>

<style scoped></style>
