<!-- 角色编辑弹窗 -->
<template>
  <el-dialog
    width="460px"
    :visible="visible"
    :close-on-click-modal="false"
    :title="isUpdate ? '修改编码' : '添加编码'"
    @update:visible="updateVisible"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="82px">
      <el-form-item label="编码:" prop="name">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.payKey"
          placeholder="请输入名称"
        />
      </el-form-item>
      <el-form-item label="匹配时间:" prop="mate">
        <el-input
          clearable
          type="number"
          :maxlength="20"
          v-model="form.mate"
          placeholder="匹配时间(秒)"
        />
      </el-form-item>
      <el-form-item label="类型:" prop="payType">
        <el-select v-model="form.payType" placeholder="请选择" @change="$forceUpdate()">
          <el-option
            v-for="item in payTypeAll"
            :key="item.id"
            :label="item.label"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="remark:">
        <el-input type="textarea" v-model="form.remark"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer">
      <el-button @click="updateVisible(false)">取消</el-button>
      <el-button type="primary" @click="save" :loading="loading">
        保存
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {saveOrUpdate} from "@/api/manager/aisle/paytype";

  const DEFAULT_FORM = {
    payKey: "",
    payType: "",
    remark: "",
    id: "",
    createTime: "",
    status: false,
    mate: 60
  };

  export default {
    name: 'paytypeEdit',
    props: {
      // 弹窗是否打开
      visible: Boolean,
      // 修改回显的数据
      data: Object
    },
    data() {
      return {
        // 表单数据
        form: {...DEFAULT_FORM},
        // 表单验证规则
        rules: {},
        // 提交状态
        loading: false,
        // 是否是修改
        isUpdate: false,
        payTypeAll: [{
          id: 1,
          key: "WECHAT",
          label: "微信",
        },
          {
            id: 2,
            key: "ALIPAY",
            label: "支付宝",
          }, {
            id: 3,
            key: "YUN",
            label: "云闪付",
          }, {
            id: 4,
            key: "QQ",
            label: "qq",
          }]
      };
    },
    methods: {
      /* 保存编辑 */
      save() {
        this.$refs['form'].validate((valid) => {
          if (!valid) {
            return false;
          }
          this.loading = true;
          saveOrUpdate(this.form)
            .then((msg) => {
              this.loading = false;
              this.$message.success(msg);
              this.updateVisible(false);
              this.$emit('done');
            })
            .catch((e) => {
              this.loading = false;
              this.$message.error(e.message);
            });
        });
      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visible', value);
      }
    },
    watch: {
      visible(visible) {
        if (visible) {
          if (this.data) {
            this.$util.assignObject(this.form, this.data);
            this.isUpdate = true;
          } else {
            this.isUpdate = false;
          }
        } else {
          this.$refs['form'].clearValidate();
          this.form = {...DEFAULT_FORM};
        }
      }
    }
  };
</script>

<style scoped></style>
