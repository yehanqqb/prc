<!-- 角色编辑弹窗 -->
<template>
  <el-dialog
    width="460px"
    :visible="visible"
    :close-on-click-modal="false"
    :title="isUpdate ? '修改租户' : '添加租户'"
    @update:visible="updateVisible"
  >
    <el-form ref="form" v-if="isUpdate" :model="form" :rules="rules" label-width="82px">
      <el-form-item label="用户名:" prop="username">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.username"
          placeholder="请输入名称"
          disabled
        />
      </el-form-item>
      <el-form-item label="密码:" prop="password">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.password"
          placeholder="请输入名称"
        />
      </el-form-item>
      <el-form-item label="密钥:" prop="secret">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.secret"
          placeholder="请输入密钥"
        />
      </el-form-item>
      <el-form-item label="状态:">
        <el-switch
          :active-value="true"
          :inactive-value="false"
          v-model="form.status"
        />
      </el-form-item>
      <el-form-item label="额外权限:">
        <el-select v-model="form.authorityIds" multiple placeholder="请选择" @change="$forceUpdate()">
          <el-option
            v-for="item in authorityAll"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="通道:">
        <el-select v-model="form.aisles" multiple placeholder="请选择" @change="$forceUpdate()">
          <el-option
            v-for="item in aisleAll"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <el-form ref="form" v-if="!isUpdate" :model="form" :rules="rules" label-width="82px">
      <el-form-item label="用户名:" prop="username">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.username"
          placeholder="请输入名称"
        />
      </el-form-item>
      <el-form-item label="密码:" prop="password">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.password"
          placeholder="请输入密码"
        />
      </el-form-item>
    </el-form>
    <div slot="footer">
      <el-button @click="updateVisible(false)">取消</el-button>
      <el-button type="primary" @click="save" :loading="loading">
        保存
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {save, saveAisle, update} from "@/api/manager/user/tenant";
  import {pageList} from "@/api/manager/system/auth";
  import {pageList as pageAisleList} from "@/api/manager/aisle/list";

  const DEFAULT_FORM = {
    username: '',
    password: '',
    userId: "",
    tenantId: "",
    mountIds: [],
    authorityIds: [],
    secret: "",
    status: false,
    aisles: []
  };

  export default {
    name: 'RoleEdit',
    props: {
      // 弹窗是否打开
      visible: Boolean,
      // 修改回显的数据
      data: Object
    },
    data() {
      return {
        // 表单数据
        form: {...DEFAULT_FORM},
        // 表单验证规则
        rules: {},
        // 提交状态
        loading: false,
        // 是否是修改
        isUpdate: false,
        authorityAll: [],
        aisleAll: []
      };
    },
    created() {
      let param = {
        limit: 1000,
        page: 1
      };
      pageList(param).then(res => {
        let array = [];
        for (let i = 0; i < res.list.length; i++) {
          if ((res.list)[i].hasRole === false) {
            array.push((res.list)[i]);
          }
        }
        this.authorityAll = array;
      })

      pageAisleList(param).then(res => {
        let array = [];
        for (let i = 0; i < res.list.length; i++) {
          array.push((res.list)[i]);
        }
        this.aisleAll = array;
      })
    },
    methods: {
      /* 保存编辑 */
      save() {
        this.$refs['form'].validate((valid) => {
          if (!valid) {
            return false;
          }
          this.loading = true;
          if (this.isUpdate) {
            update(this.form.tenantId, this.form)
              .then((msg) => {
                this.loading = false;
                this.$message.success(msg);
                this.updateVisible(false);
                this.$emit('done');
              })
              .catch((e) => {
                this.loading = false;
                this.$message.error(e.message);
              });
          } else {
            save(this.form)
              .then((msg) => {
                this.loading = false;
                this.$message.success(msg);
                this.updateVisible(false);
                this.$emit('done');
              })
              .catch((e) => {
                this.loading = false;
                this.$message.error(e.message);
              });
          }

        });

      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visible', value);
      }
    },
    watch: {
      visible(visible) {
        if (visible) {
          if (this.data) {
            this.$util.assignObject(this.form, this.data);
            this.isUpdate = true;
          } else {
            this.isUpdate = false;
          }
        } else {
          this.$refs['form'].clearValidate();
          this.form = {...DEFAULT_FORM};
        }
      }
    }
  };
</script>

<style scoped></style>
