<!-- 角色编辑弹窗 -->
<template>
  <el-dialog
    width="460px"
    :visible="visible"
    :close-on-click-modal="false"
    @update:visible="updateVisible"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="82px">
      <el-form-item label="号码:" prop="productNo">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.productNo"
          placeholder="请输入名称"
        />
      </el-form-item>
      <el-form-item label="租户id:" prop="tenantId">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.tenantId"
          placeholder="请输入名称"
        />
      </el-form-item>
      <el-form-item label="供货商id:" prop="supplierId">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.supplierId"
          placeholder="请输入名称"
        />
      </el-form-item>
      <el-form-item label="金额:" prop="money">
        <el-input
          clearable
          :maxlength="20"
          v-model="form.money"
          placeholder="请输入金额"
        />
      </el-form-item>
      <el-form-item label="运行商:" prop="operators">
        <el-select v-model="form.operator"  placeholder="请选择" @change="$forceUpdate()">
          <el-option
            v-for="item in operatorsAll"
            :key="item.id"
            :label="item.value"
            :value="item.key">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="是否慢充:">
        <el-switch
          :active-value="true"
          :inactive-value="false"
          v-model="form.slow"
        />
      </el-form-item>
    </el-form>
    <div slot="footer">
      <el-button @click="updateVisible(false)">取消</el-button>
      <el-button type="primary" @click="save" :loading="loading">
        保存
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {test} from "@/api/manager/indent/supplier";

  const DEFAULT_FORM = {
    productNo: '',
    tenantId: "",
    money: 100,
    slow: false,
    orderId: "1",
    operator:"",
    notifyUrl:"",
    sign:"",
    ext:{}
  };

  export default {
    name: 'RoleEdit',
    props: {
      // 弹窗是否打开
      visible: Boolean,
      // 修改回显的数据
      data: Object
    },
    data() {
      return {
        // 表单数据
        form: {...DEFAULT_FORM},
        // 表单验证规则
        rules: {},
        // 提交状态
        loading: false,
        // 是否是修改
        isUpdate: false,
        authorityAll: [],
        aisleAll: [],
        operatorsAll:[ {id: 0, key: "DX", value: "电信"},
          {id: 1, key: "LT", value: "联通"},
          {id: 2, key: "YD", value: "移动"},
          {id: 3, key: "OTHER", value: "自由金额"},]
      };
    },
    created() {

    },
    methods: {
      /* 保存编辑 */
      save() {
        this.$refs['form'].validate((valid) => {
          if (!valid) {
            return false;
          }
          this.loading = true;
          test(this.form)
            .then((msg) => {
              this.loading = false;
              this.$message.success(msg);
              this.updateVisible(false);
              this.$emit('done');
            })
            .catch((e) => {
              this.loading = false;
              this.$message.error(e.message);
            });
        });
      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visible', value);
      }
    },
    watch: {
      visible(visible) {
        if (visible) {
          if (this.data) {
            this.$util.assignObject(this.form, this.data);
            this.isUpdate = true;
          } else {
            this.isUpdate = false;
          }
        } else {
          this.$refs['form'].clearValidate();
          this.form = {...DEFAULT_FORM};
        }
      }
    }
  };
</script>

<style scoped></style>
