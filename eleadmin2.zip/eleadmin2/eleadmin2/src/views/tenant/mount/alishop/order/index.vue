<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <merchant-search @search="reload"/>
      <!-- 数据表格 -->
      <el-alert type="info" :closable="true" class="ele-alert-border" style="margin-bottom: 15px">
        <span class="ele-text">
          <span>
            总缴费：<el-button size="mini" type="primary">{{title.allMoney}}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            成功缴费：<el-button size="mini" type="success">{{title.successMoney }}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            成功单数：<el-button size="mini" type="success"> {{title.successCount}}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            监控掉线：<el-button size="mini" type="primary">{{title.errorCount}}</el-button>
          </span>
        </span>
      </el-alert>
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >
        <template slot="status" slot-scope="{ row }">

          <ele-dot :ripple="row.status" :type="['success', 'danger'][row.status?0:1]"
                   :text="['成功', '掉线'][row.status?0:1]"/>
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">

        </template>
      </ele-pro-table>
    </el-card>
    <merchant-edit :data="current" :visible.sync="showEdit" @done="reload"/>
  </div>
</template>

<script>
  import merchantSearch from './components/t-merchant-search';
  import merchantEdit from './components/t-merchant-details';
  import {pageList, getTitle} from '@/api/tenant/mount/alishop/order';
  import {getDayTime, isNull, pageParam} from "@/utils/application";

  export default {
    name: 'MMerchantOrder',
    components: {
      merchantSearch,
      merchantEdit
    },
    data() {
      return {
        // 表格列配置
        columns: [
          {
            columnKey: 'selection',
            type: 'selection',
            width: 45,
            align: 'center'
          },
          {
            columnKey: 'index',
            type: 'index',
            width: 45,
            align: 'center',
            showOverflowTooltip: true
          },
          {
            prop: 'supplierId',
            label: '供货商Id',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 120,
          },
          {
            prop: 'paymentId',
            label: '支付单号',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 120
          },
          {
            prop: 'payerId',
            label: '淘宝单号',
            align: 'center',
            sortable: 'custom',
            minWidth: 120,
          },
          {
            prop: 'money',
            label: '金额',
            align: 'center',
            sortable: 'custom',
            width: 120,
          },
          {
            prop: 'shopId',
            label: '店铺id',
            align: 'center',
            sortable: 'custom',
            width: 120,
          },
          {
            prop: 'goodsId',
            label: '商品id',
            align: 'center',
            sortable: 'custom',
            width: 120,
          },
          {
            prop: 'goodsName',
            label: '商品名称',
            align: 'center',
            sortable: 'custom',
            width: 120,
          },
          {
            prop: 'status',
            label: '状态',
            align: 'center',
            sortable: 'custom',
            slot:"status"
          },
          {
            prop: 'createTime',
            label: '创建时间',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 110,
            formatter: (row, column, cellValue) => {
              return this.$util.toDateString(cellValue);
            }
          }
        ],
        // 表格选中数据
        selection: [],
        // 当前编辑数据
        current: null,
        // 是否显示编辑弹窗
        showEdit: false,
        // 是否显示导入弹窗
        showAuth: false,
        title: {},
      };
    },
    methods: {
      /* 表格数据源 */
      datasource({page, limit, where, order}) {
        const common = {
          payerId: where.payerId,
          paymentId: where.paymentId,
          goodsName: where.goodsName,
          goodsId: where.goodsId,
          shopId: where.shopId
        };
        if (isNull(where)) {
          where.createTime = getDayTime();
        }
        const range = [];
        if (!isNull(where.createTime)) {
          range.push({
            "column": "create_time",
            "start": where.createTime[0],
            "end": where.createTime[1]
          })
        }

        const title = [{
          "name": "money",
          "type": "SUM",
          "asName": "allMoney"
        },
          {
            "name": "status",
            "type": "SUM",
            "value": "1",
            "other": "money",
            "asName": "successMoney"
          },

          {
            "name": "status",
            "type": "SUM",
            "value": "1",
            "other": "1",
            "asName": "successCount"
          },
          {
            "name": "status",
            "type": "SUM",
            "value": "0",
            "other": "1",
            "asName": "errorCount"
          }
        ];

        const params = pageParam(common, order, range, title)
        getTitle({...params, page, limit}).then(res => {
          this.title = res;
        });
        const params2 = pageParam(common, order, range, title)
        return pageList({...params2, page, limit});
      },
      /* 刷新表格 */
      reload(where) {
        this.$refs.table.reload({page: 1, where: where});
      },
    }
  };
</script>

<style scoped></style>
