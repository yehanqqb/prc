<template>
  <el-dialog
    width="460px"
    :visible="visibleGoods"
    custom-class="el-dialog-s"
    append-to-body
    :close-on-click-modal="false"
    @update:visible="updateVisible"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="82px">
      <el-form-item label="商品名称:" required>
        <el-input
          clearable
          :maxlength="200"
          v-model="form.name"
          placeholder="请输入名称"
        />
      </el-form-item>
      <el-form-item label="商品地址:" required>
        <el-input
          clearable
          :maxlength="200"
          v-model="form.path"
          placeholder="请输入地址"
        />
      </el-form-item>
      <el-form-item label="库存:" required>
        <el-input
          clearable
          type="number"
          :maxlength="200"
          v-model="form.number"
          placeholder="请输入库存"
        />
      </el-form-item>
      <el-form-item label="金额:" required>
        <el-input
          clearable
          :maxlength="200"
          type="number"
          v-model="form.money"
          placeholder="请输入金额"
        />
      </el-form-item>
      <el-form-item label="状态:" required>
        <el-switch
          :active-value="true"
          :inactive-value="false"
          v-model="form.status"
        />
      </el-form-item>
    </el-form>
    <div slot="footer">
      <el-button @click="updateVisible(false)">取消</el-button>
      <el-button type="primary" @click="save" :loading="loading">
        保存
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {saveOrUpdateGoods} from "@/api/tenant/mount/alishop/list";

  const DEFAULT_FORM = {
    name: "",
    id: "",
    shopId: "",
    path: "",
    number: "",
    money: "",
    status: true
  };
  export default {
    name: 'GoodsEdit',
    props: {
      // 弹窗是否打开
      visibleGoods: Boolean,
      // 修改回显的数据
      data: Object,
      shopId: Number,
    },
    data() {
      return {
        // 表单数据
        form: {...DEFAULT_FORM},
        // 表单验证规则
        rules: {},
        // 提交状态
        loading: false,
      };
    },
    created() {
    },
    methods: {
      save() {
        this.$refs['form'].validate((valid) => {
          if (!valid) {
            return false;
          }
          this.loading = true;
          this.form.shopId = this.shopId
          saveOrUpdateGoods(this.form).then(res => {
            this.loading = false;
            this.$message.success(res.msg);
            this.updateVisible(false);
            this.$emit('done');
          }).catch((e) => {
            this.loading = false;
            this.$message.error(e.message);
          });
        });
      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visibleGoods', value);
      }
    },
    watch: {
      visibleGoods(visibleGoods) {
        if (visibleGoods) {
          this.$util.assignObject(this.form, this.data);
        } else {
          this.$refs['form'].clearValidate();
          this.form = {...DEFAULT_FORM};
        }
      }
    }
  };
</script>
<style scoped></style>
