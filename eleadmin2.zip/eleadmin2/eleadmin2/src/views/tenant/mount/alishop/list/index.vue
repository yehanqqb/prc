<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <tenant-search @search="reload"/>
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >
        <!-- 状态列 -->
        <template slot="status" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.shop.status"
            @change="editHide(row.shop)"
          />
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-plus"
            class="ele-btn-icon"
            @click="openEdit()"
          >
            添加
          </el-button>
        </template>
        <!-- 操作列 -->
        <template slot="action" slot-scope="{ row }">
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openEdit(row)"
          >
            重新登陸
          </el-link>
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openGoods(row)"
          >
            商品管理
          </el-link>
        </template>
      </ele-pro-table>
    </el-card>
    <alishop-edit :data="current" :visible.sync="showEdit" @done="reload"/>
    <goods :data="goods" :shop-id="currentShopId" :visible.sync="showGoods" @done="reload"></goods>
  </div>
</template>

<script>
  import TenantSearch from './components/alishop-search';
  import AlishopEdit from './components/alishop-edit';
  import Goods from './components/goods';
  import {pageParam} from "@/utils/application";
  import {pageList, saveOrStatus} from "@/api/tenant/mount/alishop/list";

  export default {
    name: 'SystemAuth',
    components: {
      TenantSearch,
      AlishopEdit,
      Goods
    },
    data() {
      return {
        // 表格列配置
        columns: [
          {
            columnKey: 'selection',
            type: 'selection',
            width: 45,
            align: 'center'
          },
          {
            columnKey: 'index',
            type: 'index',
            width: 45,
            align: 'center',
            showOverflowTooltip: true
          },
          {
            prop: 'shop.id',
            label: '店铺id',
            align: 'center',
            sortable: 'custom',
            minWidth: 150,
          },
          {
            prop: 'shop.name',
            label: '店铺名称',
            align: 'center',
            sortable: 'custom',
            minWidth: 150,
          },
          {
            prop: 'shop.createTime',
            label: '创建时间',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 110,
            formatter: (row, column, cellValue) => {
              return this.$util.toDateString(cellValue);
            }
          },
          {
            prop: 'shop.status',
            label: '是否启用',
            align: 'center',
            sortable: 'custom',
            width: 120,
            resizable: false,
            slot: 'status'
          },
          {
            columnKey: 'action',
            label: '操作',
            width: 230,
            align: 'center',
            resizable: false,
            slot: 'action'
          }
        ],
        // 表格选中数据
        selection: [],
        // 当前编辑数据
        current: null,
        // 是否显示编辑弹窗
        showEdit: false,
        // 是否显示导入弹窗
        showAuth: false,
        goods: null,
        currentShopId: "",
        showGoods: false,
      };
    },
    methods: {
      /* 表格数据源 */
      datasource({page, limit, where, order}) {
        const common = {
          name: where.name,
        };
        const range = []
        const params = pageParam(common, order, range)
        return pageList({...params, page, limit});
      },
      /* 刷新表格 */
      reload(where) {
        this.$refs.table.reload({page: 1, where: where});
      },
      /* 显示编辑 */
      openEdit(row) {
        if (row !== null && row !== undefined) {
          this.current = row.shop;
        }
        this.showEdit = true;
      },
      /* 显示编辑 */
      openGoods(data) {
        this.goods = data.goods;
        this.showGoods = true;
        this.currentShopId = data.shop.id
      },
      /* 更改状态 */
      editHide(row) {
        const loading = this.$loading({lock: true});
        saveOrStatus(row.id, row.status)
          .then((msg) => {
            loading.close();
            this.$message.success(msg);
          })
          .catch((e) => {
            loading.close();
            this.$message.error(e.message);
          });
      },
    }
  };
</script>

<style scoped></style>
