<!-- 角色编辑弹窗 -->
<template>
  <el-dialog
    width="460px"
    :visible="visible"
    :close-on-click-modal="false"
    @update:visible="updateVisible"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="82px">
      <el-form-item label="店铺名称:" required>
        <el-input
          clearable
          :maxlength="200"
          v-model="form.name"
          placeholder="请输入名称"
        />
      </el-form-item>
      <el-form-item label="扫码登录:">
        <div id="qrCode" ref="qrCode" v-show="visQR"></div>
        <div v-show="succ">登录成功</div>
        <el-input
          v-show="visSms"
          clearable
          :maxlength="200"
          v-model="sms"
          placeholder="请输入验证码"
        />
        <br>
        <el-button v-show="visSms" type="primary" @click="checkSm">提交验证码</el-button>
      </el-form-item>

    </el-form>
    <div slot="footer">
      <el-button @click="updateVisible(false)">取消</el-button>
      <el-button type="primary" @click="save" :loading="loading">
        保存
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
  import QRCode from "qrcodejs2";
  import {checkQr, checkSms, getQr, saveOrUpdateShop} from "@/api/tenant/mount/alishop/list";

  const DEFAULT_FORM = {
    name: "",
    id: ""
  };

  export default {
    name: 'RoleEdit',
    props: {
      // 弹窗是否打开
      visible: Boolean,
      // 修改回显的数据
      data: Object
    },
    data() {
      return {
        // 表单数据
        form: {...DEFAULT_FORM},
        // 表单验证规则
        rules: {},
        // 提交状态
        loading: false,
        interval: Object,
        qrCode: Object,
        visQR: true,
        idp: "",
        visSms: false,
        sms: "",
        succ: false,
      };
    },
    created() {

    },
    methods: {
      startIdp(idp) {
        this.interval = setInterval(() => {
          this.check(idp)
        }, 10000)
      },
      checkSm() {
        checkSms(this.idp, this.sms).then(res => {
          if (res.code === 200) {
            this.visQR = false;
            this.visSms = false;
            this.succ = true
          } else {
            this.$message.error(res.msg);
          }
        })
      },
      check(idp) {
        checkQr(idp).then(res => {
          if (res.code === 200) {
            clearInterval(this.interval);
            this.clearQr();
            this.visQR = false;
            this.succ = true;
          } else if (res.code === 3) {
            this.clearQr();
            this.visQR = false;
            clearInterval(this.interval);
            this.visSms = true;
          } else if (res.code === 1) {
            this.clearQr();
            clearInterval(this.interval);
            this.createIdp();
          }
        })
      },
      clearQr() {
        this.$refs.qrCode.innerHTML = "";
      },
      /* 保存编辑 */
      save() {
        this.$refs['form'].validate((valid) => {
          if (!valid) {
            return false;
          }
          if (this.visQR) {
            this.$message.error("请先登录");
            return false;
          }
          this.loading = true;
          saveOrUpdateShop({name: this.form.name, idp: this.idp, id: this.form.id}).then(res => {
            this.loading = false;
            this.$message.success(res.msg);
            this.updateVisible(false);
            this.$emit('done');
          }).catch((e) => {
            this.loading = false;
            this.$message.error(e.message);
          });
        });
      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visible', value);
      },
      createIdp() {
        const idp = new Date().getTime();
        getQr(idp).then(res => {
          this.qrCode = new QRCode("qrCode", {
            width: 250, // 二维码宽度，单位像素
            height: 250, // 二维码高度，单位像素
            text: res.qrPath,
            correctLevel: 3
          });
        })
        this.startIdp(idp);
        this.idp = idp
      }
    },
    watch: {
      visible(visible) {
        if (visible) {
          if (this.data) {
            this.$util.assignObject(this.form, this.data);
            this.isUpdate = true;
          } else {
            this.isUpdate = false;
          }
          this.createIdp();
        } else {
          this.$refs['form'].clearValidate();
          this.form = {...DEFAULT_FORM};
        }
      }
    }
  };
</script>

<style scoped></style>
