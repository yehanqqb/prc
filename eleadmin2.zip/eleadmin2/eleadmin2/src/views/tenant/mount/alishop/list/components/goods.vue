<template>
  <el-dialog
    width="1000px"
    :visible="visible"
    :close-on-click-modal="false"
    @update:visible="updateVisible"
  >
    <div class="ele-body">
      <el-card shadow="never">
        <el-button @click="update()" type="primary" size="small">新增</el-button>
        <template>
          <el-table
            :data="data"
            style="width: 100%">
            <el-table-column
              prop="id"
              label="商品"
              width="180">
            </el-table-column>
            <el-table-column
              prop="path"
              label="商品链接"
              width="180">
            </el-table-column>
            <el-table-column
              prop="name"
              label="商品名称">
            </el-table-column>
            <el-table-column
              prop="number"
              label="库存"
              width="180">
            </el-table-column>
            <el-table-column
              prop="successNumber"
              label="已成交"
              width="180">
            </el-table-column>
            <el-table-column
              prop="status"
              label="状态"
              width="180">
              <template slot-scope="scope">
                <el-switch
                  :active-value="true"
                  :inactive-value="false"
                  v-model="scope.row.status"
                  disabled
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="money"
              label="金额"
              width="180">
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="100">
              <template slot-scope="scope">
                <el-button @click="update(scope.row)" type="text" size="small">修改</el-button>
              </template>
            </el-table-column>
          </el-table>
        </template>
      </el-card>
      <good-edit :data="currentGood" :shop-id="shopId" :visibleGoods.sync="showEditGood"></good-edit>
    </div>
  </el-dialog>
</template>

<script>
  import GoodEdit from "./goods-edit";

  export default {
    props: {
      // 弹窗是否打开
      visible: Boolean,
      // 修改回显的数据
      data: Object,
      shopId: Number
    },
    name: 'SystemAuth',
    components: {
      GoodEdit
    },
    data() {
      return {
        currentGood: null,
        showEditGood: false
      };
    },
    methods: {
      update(row) {
        if (row !== null && row !== undefined) {
          this.currentGood = row;
        }
        this.showEditGood = true;
      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visible', value);
      }
    }
  };
</script>

<style scoped></style>
