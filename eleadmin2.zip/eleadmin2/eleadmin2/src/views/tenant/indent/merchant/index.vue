<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <merchant-search @search="reload"/>
      <!-- 数据表格 -->
      <el-alert type="info" :closable="true" class="ele-alert-border" style="margin-bottom: 15px">
        <span class="ele-text">
          <span>
            总缴费：<el-button size="mini" type="primary">{{ title.allMoney }}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            成功缴费：<el-button size="mini" type="success">{{ title.successMoney }}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            成功率：<el-button size="mini" type="success"> {{title.ALLCOUNT === 0 ? 0 : ((title.successCount / title.ALLCOUNT) * 100).toFixed(2)}}%</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            总订单数：<el-button size="mini" type="primary">{{title.ALLCOUNT}}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            成功订单数：<el-button size="mini" type="success"> {{title.successCount}}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            未支付订单数：<el-button size="mini" type="danger"> {{title.ALLCOUNT-title.successCount}}</el-button>
          </span>
        </span>
      </el-alert>
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >
        <template slot="notify" slot-scope="{ row }">

          <ele-dot :ripple="row.notify" :type="['success', 'danger'][row.notify?0:1]"
                   :text="['已通知', '未通知'][row.notify?0:1]"/>
        </template>
        <template slot="payStatus" slot-scope="{ row }">
          <el-button
            size="mini"
            :disable-transitions="true"
            :type="['warning', 'primary', 'success', 'danger', 'info','success','danger','danger','danger','danger'][row.payStatus]">
            {{ ['等待中', '支付中', '支付成功', '支付失败', '产码失败', '批量失败', '通知失败','产码中','超时','不可付'][row.payStatus] }}
          </el-button>
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-warning-outline"
            class="ele-btn-icon"
            @click="batchNotify()"
          >
            批量成功
          </el-button>
        </template>
      </ele-pro-table>
    </el-card>
    <merchant-edit :data="current" :visible.sync="showEdit" @done="reload"/>
  </div>
</template>

<script>
  import merchantSearch from './components/t-merchant-search';
  import merchantEdit from './components/t-merchant-details';
  import {pageList, reissue, getTitle} from '@/api/tenant/indent/merchant';
  import {getDayTime, isNull, pageParam} from "@/utils/application";

  export default {
    name: 'MMerchantOrder',
    components: {
      merchantSearch,
      merchantEdit
    },
    data() {
      return {
        // 表格列配置
        columns: [
          {
            columnKey: 'selection',
            type: 'selection',
            width: 45,
            align: 'center'
          },
          {
            columnKey: 'index',
            type: 'index',
            width: 45,
            align: 'center',
            showOverflowTooltip: true
          },
          {
            prop: 'merchantId',
            label: '商户id',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 80,
          },
          {
            prop: 'orderId',
            label: '订单号',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 120
          },
          {
            prop: 'paymentId',
            label: '支付单号',
            align: 'center',
            sortable: 'custom',
            minWidth: 120,
          },
          {
            prop: 'money',
            label: '金额',
            align: 'center',
            sortable: 'custom',
            width: 80,
          },
          {
            prop: 'payType',
            label: '编码',
            align: 'center',
            sortable: 'custom',
            width: 80,
          },
          {
            prop: 'payStatus',
            label: '支付状态',
            align: 'center',
            sortable: 'custom',
            width: 120,
            slot: "payStatus"
          },
          {
            prop: 'notify',
            label: '是否通知',
            align: 'center',
            sortable: 'custom',
            width: 120,
            slot: "notify"
          },
          {
            prop: 'remark',
            label: '说明',
            align: 'center',
            sortable: 'custom',
            width: 120,
          },
          {
            prop: 'createTime',
            label: '创建时间',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 110,
            formatter: (row, column, cellValue) => {
              return this.$util.toDateString(cellValue);
            }
          }
        ],
        // 表格选中数据
        selection: [],
        // 当前编辑数据
        current: null,
        // 是否显示编辑弹窗
        showEdit: false,
        // 是否显示导入弹窗
        showAuth: false,
        title: {},
      };
    },
    methods: {
      /* 表格数据源 */
      datasource({page, limit, where, order}) {
        const common = {
          merchantId: where.merchantId,
          orderId: where.orderId,
          paymentId: where.paymentId,
          notify: where.notify,
          payStatus: where.payStatus,
          money: where.money,
          payType: where.payType
        };
        if (isNull(where)) {
          where.createTime = getDayTime();
        }
        const range = [];
        if (!isNull(where.createTime)) {
          range.push({
            "column": "create_time",
            "start": where.createTime[0],
            "end": where.createTime[1]
          })
        } else {

        }

        const title = [{
          "name": "money",
          "type": "SUM",
          "asName": "allMoney"
        },
          {
            "name": "pay_status",
            "type": "SUM",
            "value": "2",
            "other": "money",
            "asName": "successMoney"
          },
          {
            "name": "pay_status",
            "type": "SUM",
            "value": "2",
            "other": "1",
            "asName": "successCount"
          }];

        const params = pageParam(common, order, range, title)
        getTitle({...params, page, limit}).then(res => {
          this.title = res;
        });
        const params2 = pageParam(common, order, range, title)
        return pageList({...params2, page, limit});
      },
      /* 刷新表格 */
      reload(where) {

        this.$refs.table.reload({page: 1, where: where});
      },
      batchNotify() {
        if (!this.selection.length) {
          this.$message.error('请至少选择一条数据');
          return;
        }
        this.$confirm('确定要通知吗?', '提示', {
          type: 'warning'
        })
          .then(() => {
            reissue({ids: this.selection.map(item => item.id)}).then(res => {
              this.$message.success(res);
              this.reload();
            })
              .catch((e) => {
                this.$message.error(e.message);
              });
          })
          .catch(() => {
          });
      },
    }
  };
</script>

<style scoped></style>
