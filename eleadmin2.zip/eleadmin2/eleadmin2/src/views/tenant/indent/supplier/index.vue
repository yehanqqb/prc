<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <payment-search @search="reload"/>
      <el-alert type="info" :closable="true" class="ele-alert-border" style="margin-bottom: 15px">
        <span class="ele-text">
          <span>
            总单数：<el-button size="mini" type="primary">{{ title.ALLCOUNT }}</el-button>
          </span>
           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           <span>
            等待缴费单数：<el-button size="mini" type="primary">{{ title.waitCount }}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            等待缴费：<el-button size="mini" type="primary">￥{{ title.payWaitMoney  }}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           <span>
            成功单数：<el-button size="mini" type="success">{{ title.paySuccessCount}}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            缴费成功：<el-button size="mini" type="success">￥{{ title.successMoney }}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            到账金额：<el-button size="mini" type="primary">￥{{ title.finishMoney }}</el-button>
          </span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>
            到账单数：<el-button size="mini" type="success">{{ title.finishCount}}</el-button>
          </span>
        </span>
      </el-alert>
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >
        <template slot="notify" slot-scope="{ row }">

          <ele-dot :ripple="row.notify" :type="['success', 'danger'][row.notify?0:1]"
                   :text="['已通知', '未通知'][row.notify?0:1]"/>
        </template>
        <template slot="payStatus" slot-scope="{ row }">
          <el-button
            size="mini"
            :disable-transitions="true"
            :type="['warning', 'primary', 'success', 'danger', 'info','success','danger','danger','danger','danger'][row.payStatus]">
            {{ ['等待中', '支付中', '支付成功', '支付失败', '产码失败', '批量失败', '通知失败','产码中','超时','不可付'][row.payStatus] }}
          </el-button>
        </template>
        <template slot="finishStatus" slot-scope="{ row }">
          <el-button
            size="mini"
            :disable-transitions="true"
            :type="['warning', 'success', 'danger', 'info'][row.finishStatus]">
            {{ ['等待中', '已到账', '返销', '退单'][row.finishStatus] }}
          </el-button>
        </template>
        <template slot="slow" slot-scope="{ row }">
          <el-button
            size="mini"
            :disable-transitions="true"
            :type="row.slow?'warning':'primary'">
            {{ row.slow?'慢':'快' }}
          </el-button>
        </template>
        <template slot="operator" slot-scope="{ row }">
          {{["电信","联通","移动","自由金额"][row.operator]}}
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="danger"
            icon="el-icon-warning-outline"
            class="ele-btn-icon"
            @click="batchErrorSave()"
          >
            批量失败
          </el-button>
        </template>
        <template slot="toolbar">
          <el-popconfirm
            class="ele-action"
            title="确定要强制失败吗（包含支付中的订单）？"
            @confirm="batchErrorImgSave()"
          >
            <el-button
              type="danger"
              size="small"
              slot="reference"
              :underline="false"
              icon="el-icon-edit"
            >
              强制失败
            </el-button>
          </el-popconfirm>
        </template>
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-warning-outline"
            class="ele-btn-icon"
            @click="batchNotify()"
          >
            批量成功
          </el-button>
          <el-button
            size="small"
            type="primary"
            icon="el-icon-warning-outline"
            class="ele-btn-icon"
            @click="openTest()"
          >
            新增测试单
          </el-button>
        </template>
      </ele-pro-table>
    </el-card>
    <payment-edit :data="current" :visible.sync="showEdit" @done="reload"/>
    <addtest :visible.sync="showTest" @done="reload"/>

  </div>
</template>

<script>
  import paymentSearch from './components/t-supplier-search';
  import paymentEdit from './components/t-supplier-details';
  import {getDayTime, isNull, pageParam} from "@/utils/application";
  import {batchError, pageList, reissue, getTitle, batchErrorImg} from "@/api/tenant/indent/supplier";
  import addtest from './components/t-addtest';

  export default {
    name: 'MMerchantOrder',
    components: {
      paymentSearch,
      paymentEdit,
      addtest
    },
    data() {
      return {
        // 表格列配置
        columns: [
          {
            columnKey: 'selection',
            type: 'selection',
            width: 45,
            align: 'center'
          },
          {
            columnKey: 'index',
            type: 'index',
            width: 45,
            align: 'center',
            showOverflowTooltip: true
          },
          {
            prop: 'supplierId',
            label: '供货商id',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 80,
          },
          {
            prop: 'orderId',
            label: '供货单号',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 120
          },
          {
            prop: 'paymentId',
            label: '支付单号',
            align: 'center',
            sortable: 'custom',
            minWidth: 120,
          },
          {
            prop: 'money',
            label: '金额',
            align: 'center',
            sortable: 'custom',
            width: 80,
          },
          {
            prop: 'operator',
            label: '运营商',
            align: 'center',
            sortable: 'custom',
            width: 80,
            slot: "operator"
          },
          {
            prop: 'payStatus',
            label: '支付状态',
            align: 'center',
            sortable: 'custom',
            width: 120,
            slot: "payStatus"
          },
          {
            prop: 'finishStatus',
            label: '到账状态',
            align: 'center',
            sortable: 'custom',
            width: 120,
            slot: "finishStatus"
          },
          {
            prop: 'notify',
            label: '通知',
            align: 'center',
            sortable: 'custom',
            width: 120,
            slot: "notify"
          },
          {
            prop: 'slow',
            label: '充值类型',
            align: 'center',
            sortable: 'custom',
            width: 120,
            slot: "slow"
          },
          {
            prop: 'productNo',
            label: '充值号码',
            align: 'center',
            sortable: 'custom',
            width: 80,
          },
          {
            prop: 'provinceName',
            label: '省份',
            align: 'center',
            sortable: 'custom',
            width: 80,
          },

          {
            prop: 'finishDate',
            label: '到账时间',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 110,
            formatter: (row, column, cellValue) => {
              return this.$util.toDateString(cellValue);
            }
          },
          {
            prop: 'createTime',
            label: '创建时间',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 110,
            formatter: (row, column, cellValue) => {
              return this.$util.toDateString(cellValue);
            }
          },
          {
            prop: 'updateTime',
            label: '更新时间',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 110,
            formatter: (row, column, cellValue) => {
              return this.$util.toDateString(cellValue);
            }
          }
        ],
        // 表格选中数据
        selection: [],
        // 当前编辑数据
        current: null,
        // 是否显示编辑弹窗
        showEdit: false,
        // 是否显示导入弹窗
        showAuth: false,
        title: {},
        showTest: false,
      };
    },
    methods: {
      openTest() {
        this.showTest = true;
      },
      /* 表格数据源 */
      datasource({page, limit, where, order}) {
        const common = {
          paymentId: where.paymentId,
          payStatus: where.payStatus,
          money: where.money,
          payType: where.payType,
          productNo: where.productNo,
          orderId: where.orderId,
          operator: where.operator,
          notify: where.notify,
          paymentNo: where.paymentNo,
          slow: where.slow,
          finishStatus: where.finishStatus,
          supplierId: where.supplierId
        };
        const range = [];
        if (isNull(where)) {
          where.createTime = getDayTime();
        }
        if (!isNull(where.createTime)) {
          range.push({
            "column": "create_time",
            "start": where.createTime[0],
            "end": where.createTime[1]
          })
        } else {

        }
        if (!isNull(where.finishTime)) {
          range.push({
            "column": "finish_time",
            "start": where.finishTime[0],
            "end": where.finishTime[1]
          })
        }
        // 表头统计
        const title = [{
          "name": "money",
          "type": "SUM",
          asName: "allMoney"
        },
          {
            "name": "pay_status",
            "type": "SUM",
            "value": "0",
            asName: "waitCount",
            other: "1"
          },
          {
            "name": "pay_status",
            "type": "SUM",
            "value": "2",
            "other": "money",
            asName: "successMoney"
          },
          {
            "name": "finish_status",
            "type": "SUM",
            "value": "1",
            "other": "money",
            asName: "finishMoney"
          },
          {
            "name": "finish_status",
            "type": "SUM",
            "value": "1",
            asName: "finishCount",
            other: "1"
          },
          {
            "name": "pay_status",
            "type": "SUM",
            "value": "2",
            asName: "paySuccessCount",
            other: "1"
          },
          {
            "name": "pay_status",
            "type": "SUM",
            "value": "0",
            "other": "money",
            asName: "payWaitMoney"
          }];

        const params = pageParam(common, order, range, title)
        getTitle({...params, page, limit}).then(res => {
          this.title = res;
        });
        const params2 = pageParam(common, order, range, title)
        return pageList({...params2, page, limit});
      },
      /* 刷新表格 */
      reload(where) {
        this.$refs.table.reload({page: 1, where: where});
      },
      batchNotify() {
        if (!this.selection.length) {
          this.$message.error('请至少选择一条数据');
          return;
        }
        this.$confirm('确定要通知吗?', '提示', {
          type: 'warning'
        })
          .then(() => {
            reissue({ids: this.selection.map(item => item.id)}).then(res => {
              this.$message.success(res);
              this.reload();
            })
              .catch((e) => {
                this.$message.error(e.message);
              });
          })
          .catch(() => {
          });
      },
      batchErrorSave() {
        if (!this.selection.length) {
          this.$message.error('请至少选择一条数据');
          return;
        }
        this.$confirm('确定要失败吗?', '提示', {
          type: 'warning'
        })
          .then(() => {
            batchError({ids: this.selection.map(item => item.id)}).then(res => {
              this.$message.success(res);
              this.reload();
            })
              .catch((e) => {
                this.$message.error(e.message);
              });
          })
          .catch(() => {
          });
      },
      batchErrorImgSave() {
        if (!this.selection.length) {
          this.$message.error('请至少选择一条数据');
          return;
        }
        this.$confirm('确定要失败吗?', '提示', {
          type: 'warning'
        })
          .then(() => {
            batchErrorImg({ids: this.selection.map(item => item.id)}).then(res => {
              this.$message.success(res);
              this.reload();
            })
              .catch((e) => {
                this.$message.error(e.message);
              });
          })
          .catch(() => {
          });
      }
    }
  };
</script>

<style scoped></style>
