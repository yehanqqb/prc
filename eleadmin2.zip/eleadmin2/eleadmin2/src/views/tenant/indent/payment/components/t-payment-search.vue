<!-- 搜索表单 -->
<template>
  <el-form
    label-width="77px"
    class="ele-form-search"
    @keyup.enter.native="search"
    @submit.native.prevent
  >
    <el-row :gutter="24">
      <el-col :lg="4">
        <el-form-item label="商户id:">
          <el-input clearable v-model="where.merchantId" placeholder="请输入"/>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="商户单号:">
          <el-input clearable v-model="where.merchantOrderId" placeholder="请输入"/>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="支付单号:">
          <el-input clearable v-model="where.paymentId" placeholder="请输入"/>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="供货单号:">
          <el-input clearable v-model="where.supplierOrderId" placeholder="请输入"/>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="官方单号:">
          <el-input clearable v-model="where.paymentNo" placeholder="请输入"/>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="金额:">
          <el-input clearable v-model="where.money" placeholder="请输入"/>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row :gutter="24">
      <el-col :lg="4">
        <el-form-item label="号码:">
          <el-input clearable v-model="where.productNo" placeholder="请输入"/>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="支付编码:">
          <el-select v-model="where.payType" placeholder="请选择" @change="$forceUpdate()">
            <el-option
              v-for="item in payTypeAll"
              :key="item.payKey"
              :label="item.payKey"
              :value="item.payKey">
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="商户通知:">
          <el-select v-model="where.merchantNotify" placeholder="请选择" clearable class="ele-fluid el-item-style">
            <el-option label="是" value="true"/>
            <el-option label="否" value="false"/>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="快慢标识:">
          <el-select v-model="where.slow" placeholder="请选择" clearable class="ele-fluid el-item-style">
            <el-option label="慢" value="true"/>
            <el-option label="快" value="false"/>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="供货通知:">
          <el-select v-model="where.supplierNotify" placeholder="请选择" clearable class="ele-fluid el-item-style">
            <el-option label="是" value="true"/>
            <el-option label="否" value="false"/>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="支付状态:">
          <el-select v-model="where.payStatus" placeholder="请选择" clearable class="ele-fluid el-item-style">
            <el-option label="等待中" value="0"/>
            <el-option label="支付中" value="1"/>
            <el-option label="支付成功" value="2"/>
            <el-option label="支付失败" value="3"/>
            <el-option label="产码失败" value="4"/>
            <el-option label="批量失败" value="5"/>
            <el-option label="通知失败" value="6"/>
            <el-option label="产码中" value="7"/>
            <el-option label="超时" value="8"/>
            <el-option label="不可付" value="9"/>
          </el-select>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row :gutter="24">
      <el-col :lg="4">
        <el-form-item label="到账状态:">
          <el-select v-model="where.finishStatus" placeholder="请选择" clearable class="ele-fluid el-item-style">
            <el-option label="等待中" value="0"/>
            <el-option label="已到账" value="1"/>
            <el-option label="返销" value="2"/>
            <el-option label="退单" value="3"/>
            <el-option label="产码失败" value="4"/>
            <el-option label="批量失败" value="5"/>
            <el-option label="通知失败" value="6"/>
            <el-option label="产码中" value="7"/>
            <el-option label="超时" value="8"/>
            <el-option label="不可付" value="9"/>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :lg="4">
        <el-form-item label="运营商:">
          <el-select v-model="where.operator" placeholder="请选择" clearable class="ele-fluid el-item-style">
            <el-option label="电信" value="0"/>
            <el-option label="联通" value="1"/>
            <el-option label="移动" value="2"/>
            <el-option label="自由金额" value="3"/>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :lg="8">
        <el-form-item label="创建日期:" prop="createTime">
          <el-date-picker v-model="where.createTime" type="datetimerange" unlink-panels range-separator="至"
                          start-placeholder="开始日期" end-placeholder="结束日期" class="ele-fluid"/>
        </el-form-item>
      </el-col>
      <el-col :lg="8">
        <el-form-item label="到账日期:" prop="finishTime">
          <el-date-picker v-model="where.finishTime" type="datetimerange" unlink-panels range-separator="至"
                          start-placeholder="开始日期" end-placeholder="结束日期" class="ele-fluid"/>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row :gutter="24">
      <el-col :lg="6" :md="12">
        <div class="ele-form-actions">
          <el-button
            type="primary"
            icon="el-icon-search"
            class="ele-btn-icon"
            @click="search"
          >
            查询
          </el-button>
          <el-button @click="reset">重置</el-button>
        </div>
      </el-col>
    </el-row>
  </el-form>
</template>

<script>
  import {pageList} from "@/api/manager/aisle/paytype";
  import {getDayTime} from "@/utils/application";

  const DEFAULT_WHERE = {
    tenantId: '',
    merchantId: '',
    supplierOrderId: "",
    paymentId: "",
    supplierNotify: "",
    payStatus: "",
    money: "",
    payType: "",
    productNo: "",
    merchantOrderId: "",
    operator: "",
    merchantNotify: "",
    paymentNo: "",
    slow: "",
    finishStatus: "",
    finishTime: "",
    createTime: getDayTime()
  };

  export default {
    name: 'TenantSearch',
    data() {
      return {
        // 表单数据
        where: {...DEFAULT_WHERE},
        payTypeAll: []
      };
    },
    created() {
      let query = {};
      query['page'] = 1;
      query['limit'] = 1000;
      pageList(query).then(res => {
        this.payTypeAll = res.list
      })
    },
    methods: {
      /* 搜索 */
      search() {
        this.$emit('search', this.where);
      },
      /*  重置 */
      reset() {
        this.where = {...DEFAULT_WHERE};
        this.search();
      }
    }
  };
</script>

<style scoped></style>
