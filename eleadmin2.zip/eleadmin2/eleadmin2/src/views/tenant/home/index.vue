<template>
  <div class="ele-body ele-body-card">
    <!-- 顶部卡片 -->
    <el-card shadow="never" body-style="padding: 20px;">
      <div class="ele-cell workplace-user-card">
        <div class="ele-cell-content ele-cell">
          <el-avatar :size="68" :src="loginUser.avatar"/>
          <div class="ele-cell-content">
            <h4 class="ele-elip">
              早安，{{ loginUser.nickname }}，开始您一天的工作吧！
            </h4>
            <div class="ele-text-secondary ele-elip" style="margin-top: 8px">
              <i class="el-icon-heavy-rain"></i>
              <span><s/><s/>今日阴转小雨，22℃ - 32℃，出门记得带伞哦。</span>
            </div>
          </div>
        </div>
      </div>
    </el-card>
    <el-row :gutter="15">
      <el-col :xs="24" :sm="24" :md="8">
        <el-scrollbar>
          <el-card shadow="never" body-style="padding: 20px;min-height:331px">
            <div slot="header" class="clearfix">
              <span>数据统计</span>
            </div>
            <el-row type="flex" justify="space-between">
              <el-col :lg="23">
                <div style="display: flex;">
                  <el-date-picker
                    v-model="searchDate"
                    type="date"
                    placeholder="选择日期时间"
                    @change="handleProcessData">
                  </el-date-picker>

                </div>
              </el-col>
            </el-row>
            <br>
            <el-row v-for="item in moneyOptions" :key="item.tenantId">
              <el-col style="margin-bottom: 10px;">
                <span style="font-size: 16px; font-weight: bold;">{{ item.nickname }}</span>
              </el-col>
              <el-col style="margin-bottom: 10px;">
                <span>支付率</span>
                <el-progress :percentage="item.ratio" :format="format"></el-progress>
              </el-col>
            </el-row>
          </el-card>
        </el-scrollbar>
      </el-col>
      <el-col :md="4" :sm="12">
        <el-card shadow="never" class="monitor-count-card">
          <el-tag size="large" class="ele-tag-round">
            <i class="el-icon-s-custom"></i>
          </el-tag>
          <div class="monitor-count-card-num">￥ {{ cardData.yesterdayFinishMoney }}</div>
          <div class="monitor-count-card-text ele-text-secondary">
            昨日到账额
          </div>
          <div class="monitor-count-card-trend ele-text-success">
            <span>单数：￥ {{ cardData.yesterdayFinishCount }}</span>
          </div>
        </el-card>
      </el-col>
      <el-col :md="4" :sm="12">
        <el-card shadow="never" class="monitor-count-card">
          <el-tag size="large" class="ele-tag-round">
            <i class="el-icon-s-custom"></i>
          </el-tag>
          <div class="monitor-count-card-num">￥ {{ cardData.yesterdayPayMoney }}</div>
          <div class="monitor-count-card-text ele-text-secondary">
            昨日支付额
          </div>
          <div class="monitor-count-card-trend ele-text-success">
            <span>单数：￥ {{ cardData.yesterdayPayCount }}</span>
          </div>
        </el-card>
      </el-col>
      <el-col :md="4" :sm="12">
        <el-card shadow="never" class="monitor-count-card">
          <el-tag size="large" class="ele-tag-round">
            <i class="el-icon-s-custom"></i>
          </el-tag>
          <div class="monitor-count-card-num">￥ {{ cardData.dayFinishMoney }}</div>
          <div class="monitor-count-card-text ele-text-secondary">
            今日到账额
          </div>
          <div class="monitor-count-card-trend ele-text-success">
            <span>单数：￥ {{ cardData.yesterdayFinishCount }}</span>
          </div>
        </el-card>
      </el-col>
      <el-col :md="4" :sm="12">
        <el-card shadow="never" class="monitor-count-card">
          <el-tag size="large" class="ele-tag-round">
            <i class="el-icon-s-custom"></i>
          </el-tag>
          <div class="monitor-count-card-num">￥ {{ cardData.dayPayMoney }}</div>
          <div class="monitor-count-card-text ele-text-secondary">
            今日支付额
          </div>
          <div class="monitor-count-card-trend ele-text-success">
            <span>单数：￥ {{ cardData.dayPayCount }}</span>
          </div>
        </el-card>
      </el-col>
      <el-col :md="4" :sm="12">
        <el-card shadow="never" class="monitor-count-card">
          <el-tag size="large" class="ele-tag-round">
            <i class="el-icon-s-custom"></i>
          </el-tag>
          <div class="monitor-count-card-num">￥ {{ cardData.bankMoney }}</div>
          <div class="monitor-count-card-text ele-text-secondary">
            今日返销额
          </div>
          <div class="monitor-count-card-trend ele-text-success">
            <span>单数：￥ {{ cardData.bankCount }}</span>
          </div>
        </el-card>
      </el-col>
      <el-col :md="6" :sm="12">
        <el-card shadow="never" class="monitor-count-card">
          <el-tag size="large" type="danger" class="ele-tag-round">
            <i class="el-icon-s-flag"></i>
          </el-tag>
          <div class="monitor-count-card-num">
            <span
              style="font-size: 1.4rem"> 到账中 ￥ {{
                cardData.dayPayMoney - cardData.dayFinishMoney
              }}（{{
                   cardData.dayPayCount - cardData.dayFinishCount              }}）</span>

          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-row :gutter="15">
      <el-col :md="12" :sm="12">
        <div class="ele-body ele-body-card">
          <el-card shadow="never" body-style="padding: 20px;">
            <div slot="header" class="clearfix">
            <span>库存统计（慢充）
              <el-button size="mini">
                联通：{{ options.uniCount }}
              </el-button>
              <el-button size="mini">
                电信：{{ options.telecomCount }}
              </el-button>
              <el-button size="mini">
                移动：{{ options.mobileCount }}
              </el-button>
              <el-button size="mini">
                其他：{{ options.otherCount }}
              </el-button>
            </span>
            </div>
            <el-row :gutter="15">
              <el-col :xs="24" :sm="24" :lg="24">
                <el-card shadow="never" body-style="padding: 20px;height: 400px;" class="bar-chart-card">
                  <v-chart class="chart" :option="options"/>
                </el-card>
              </el-col>
            </el-row>
          </el-card>
        </div>
      </el-col>
      <el-col :md="12" :sm="12">
        <div class="ele-body ele-body-card">
          <el-card shadow="never" body-style="padding: 20px;">
            <div slot="header" class="clearfix">
            <span>库存统计（快充）
              <el-button size="mini">
                联通：{{ optionsFast.uniCount }}
              </el-button>
              <el-button size="mini">
                电信：{{ optionsFast.telecomCount }}
              </el-button>
              <el-button size="mini">
                移动：{{ optionsFast.mobileCount }}
              </el-button>
              <el-button size="mini">
                其他：{{ options.otherCount }}
              </el-button>
            </span>
            </div>
            <el-row :gutter="15">
              <el-col :xs="24" :sm="24" :lg="24">
                <el-card shadow="never" body-style="padding: 20px;height: 400px;" class="bar-chart-card">
                  <v-chart class="chart" :option="optionsFast"/>
                </el-card>
              </el-col>
            </el-row>
          </el-card>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import {use} from "echarts/core";
import {CanvasRenderer} from "echarts/renderers";
import {BarChart} from "echarts/charts";
import {
  TitleComponent,
  TooltipComponent,
  ToolboxComponent,
  GridComponent,
  LegendComponent
} from "echarts/components";
import VChart, {THEME_KEY} from "vue-echarts";
import {queryBarList, queryProcessList, queryCardList, queryAisleTenantCountList} from '@/api/tenant/home'
import {getDayTime, getDayTimeByDate} from "@/utils/application";
import {pageList as queryList} from "@/api/tenant/aisle";

use([
  CanvasRenderer,
  TitleComponent,
  TooltipComponent,
  ToolboxComponent,
  GridComponent,
  LegendComponent,
  BarChart,
]);

const oneDayDate = () => {
  return new Date();
}

export default {
  name: 'DashboardWorkplace',
  components: {
    VChart
  },
  provide: {
    [THEME_KEY]: "light"
  },
  data() {
    return {
      cardData: {},
      barDataList: [],
      barFastDataList: [],
      options: {},
      optionsFast: {},
      allOptions: [],
      barCollspan: false,
      searchInput: '',
      searchDate: oneDayDate(),
      moneyOptions: [],
      timer: null,
      fxoptions:[],
      aisle: {
        data: [],
        check: ""
      },
      createTime: getDayTime()
    };
  },
  mounted() {
    this.handleBarData();
    this.handleProcessData();
    this.handleCardData();
    this.timer = setInterval(() => {
      this.handleBarData();
      this.handleProcessData();
      this.handleCardData();
    }, 400000)
  },
  destroyed() {
    clearInterval(this.timer);
  },
  computed: {
    // 当前登录用户信息
    loginUser() {
      return this.$store.state.user.info;
    },
  },
  methods: {
    handleBarData() {
      queryBarList(true).then(res => {
        this.barDataList = res || [];
        this.initBarData(this.barDataList)
      })
      queryBarList(false).then(res => {
        this.barFastDataList = res || [];
        this.initBarDataFast(this.barFastDataList)
      })
      queryList(this.$store.state.user.info.tenantId).then(res => {
        console.log(res);
        this.aisle.data = res;
      })
    },
    selectAisle(value) {
      const params = {
        start: this.createTime[0],
        end: this.createTime[1],
      }
      queryAisleTenantCountList(value,this.$store.state.user.info.tenantId, params).then(res => {
        this.fxoptions = this.handleOptions2(res);
      });
      this.aisle.check = value;
      this.$forceUpdate();
    },
    handleProcessData() {
      const par = getDayTimeByDate(this.searchDate);
      const params = {
        start: par[0],
        end: par[1],
      }
      queryProcessList(params).then(res => {
        this.moneyOptions = res;
      });
      this.handleCardData();
    },

    handleCardData() {
      const par = getDayTimeByDate(this.searchDate);
      const params = {
        start: par[0],
        end: par[1],
      }
      queryCardList(params).then(res => {
        this.cardData = res;
      })
    },

    handleClick() {
      this.barCollspan = !this.barCollspan;
    },

    handleSearch() {
      this.barCollspan = true;
      if (this.searchInput) {
        this.options = this.allOptions.filter(ele => ele.title.text.indexOf(this.searchInput) !== -1);
      } else {
        this.options = this.allOptions;
      }
    },

    initBarData(barList) {
      this.options = this.handleOptions(barList);
    },

    initBarDataFast(barList) {
      this.optionsFast = this.handleOptions(barList);
    },

    format(percentage) {
      return `${percentage}`;
    },
    handleOptions2(item) {
      return {
        color: ["green","red","blue"],
        title: {
          text: item.name,
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        legend: {
          data: ['电信', '联通', '移动','其他']
        },
        xAxis: [
          {
            type: 'category',
            data: item.xaxis,
            axisPointer: {
              type: 'shadow'
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            min: 0,
            interval: 50,
            axisLabel: {
              formatter: '{value}'
            }
          },
        ],
        series: [
          {
            name: '移动',
            type: 'bar',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: item['mobile']
          },
          {
            name: '电信',
            type: 'bar',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: item['telecom']
          },
          {
            name: '联通',
            type: 'bar',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: item['uni']
          },
          {
            name: '其他',
            type: 'bar',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: item['other']
          },
        ]
      }
    },
    handleOptions(item) {
      return {
        telecomCount:item.telecomCount,
        uniCount:item.uniCount,
        mobileCount:item.mobileCount,
        otherCount:item.otherCount,
        title: {
          text: item.name,
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        legend: {
          data: ['电信', '联通', '移动','其他']
        },
        xAxis: [
          {
            type: 'category',
            data: item.xaxis,
            axisPointer: {
              type: 'shadow'
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            min: 0,
            interval: 50,
            axisLabel: {
              formatter: '{value}'
            }
          },
        ],
        series: [
          {
            name: '移动',
            type: 'bar',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: item['mobile']
          },
          {
            name: '电信',
            type: 'bar',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: item['telecom']
          },
          {
            name: '联通',
            type: 'bar',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: item['uni']
          },
          {
            name: '其他',
            type: 'bar',
            tooltip: {
              valueFormatter: function (value) {
                return value;
              }
            },
            data: item['other']
          },
        ]
      }
    }
  }
};
</script>

<style scoped>
.bar-chart-card {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 0.5s;
}

/* 顶部用户信息卡片 */
.workplace-user-card .ele-cell-content {
  overflow: hidden;
}

.workplace-count-group {
  white-space: nowrap;
}

.workplace-count-item {
  padding: 0 5px 0 25px;
  box-sizing: border-box;
  display: inline-block;
  text-align: right;
}

.workplace-count-name {
  padding-left: 8px;
}

.workplace-count-num {
  font-size: 24px;
  margin-top: 6px;
}

@media screen and (max-width: 992px) {
  .workplace-count-item {
    padding: 0 5px 0 10px;
  }
}

@media screen and (max-width: 768px) {

  .workplace-user-card,
  .workplace-count-group {
    display: block;
  }

  .workplace-count-group {
    margin-top: 15px;
    text-align: right;
  }

  .workplace-user-card ::v-deep .el-avatar {
    width: 45px !important;
    height: 45px !important;
  }

  .workplace-user-card h4 {
    font-size: 16px;
  }

  .workplace-user-card h4 + .ele-text-secondary {
    font-size: 12px;
  }

  .workplace-user-card {
    margin: -10px;
  }
}

/* 快捷方式 */
.app-link-block {
  display: block;
  color: inherit;
  padding: 15px 0;
  text-align: center;
  text-decoration: none;
  cursor: pointer;
}

.app-link-block .app-link-icon {
  color: #69c0ff;
  font-size: 30px;
  margin-top: 5px;
}

.app-link-block .app-link-title {
  margin-top: 8px;
}

/* 最新动态时间轴 */
.ele-timeline-act {
  padding-left: 50px;
}

.ele-timeline-act ::v-deep .el-timeline-item__timestamp {
  margin: 0;
  position: absolute;
  top: 3px;
  left: -45px;
}

.ele-timeline-act ::v-deep .el-timeline-item {
  padding-bottom: 19px;
}

.ele-timeline-act ::v-deep .el-timeline-item:last-child {
  padding-bottom: 0;
}

/* 表格 */
.workplace-table-card::v-deep .el-table tbody > .el-table__row:last-child td {
  border-bottom: none;
}

.workplace-table-card ::v-deep .el-table:before {
  display: none;
}

.workplace-table-card .sort-handle {
  cursor: move;
  font-size: 18px;
  vertical-align: middle;
}

.workplace-table-card ::v-deep .el-table__row.sortable-chosen {
  background-color: hsla(0, 0%, 60%, 0.1);
}

.workplace-table-card ::v-deep .el-table__row.sortable-chosen td {
  background-color: transparent;
}

/* 本月目标 */
.workplace-goal-group {
  text-align: center;
  position: relative;
  padding: 48px 0;
}

.workplace-goal-group .workplace-goal-content {
  position: absolute;
  top: 90px;
  left: 0;
  width: 100%;
}

.workplace-goal-group .workplace-goal-num {
  font-size: 40px;
  margin-top: 15px;
}

/* 小组成员 */
.user-list-item {
  padding: 13px 18px;
}

.user-list-item + .user-list-item {
  border-top: 1px solid hsla(0, 0%, 60%, 0.15);
}

.user-list-item .ele-cell-desc {
  margin-top: 5px;
}

.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}

.clearfix:after {
  clear: both
}

.box-card {
  width: 480px;
}

/* 小屏幕优化 */
@media screen and (max-width: 768px) {
}

/* 统计卡片 */
.monitor-count-card ::v-deep .el-card__body {
  padding-top: 18px;
  text-align: center;
  position: relative;
}

.monitor-count-card ::v-deep .el-tag {
  border-color: transparent;
  font-size: 15px;
}

.monitor-count-card .monitor-count-card-num {
  font-weight: 500;
  font-size: 32px;
  margin-top: 12px;
  height: 35px;
}

.monitor-count-card .monitor-count-card-text {
  font-size: 24px;
  margin: 10px 0;
  font-weight: 900;
}

.monitor-count-card .monitor-count-card-trend {
  font-size: 18px;
  font-weight: 600;
  padding: 6px 0;
}

.monitor-count-card .monitor-count-card-trend > i {
  font-size: 24px;
  font-weight: 600;
  margin-right: 5px;
}

.monitor-count-card .monitor-count-card-tips {
  position: absolute;
  top: 15px;
  right: 15px;
  cursor: pointer;
}

/* 人数分布 */
.monitor-user-count-item {
  margin-bottom: 8px;
}

.monitor-user-count-item ::v-deep .el-progress-bar__outer {
  background: none;
}

.monitor-user-count-item .ele-cell-content {
  padding-right: 10px;
}

/* 当前在线人数卡片 */
.monitor-online-num-card {
  text-align: center;
  padding: 5px 0;
}

.monitor-online-num-text {
  margin-bottom: 5px;
}

.monitor-online-num-title {
  font-size: 48px;
  margin-bottom: 10px;
}

@media screen and (max-width: 1200px) {
  .monitor-online-num-card {
    padding: 42px 0;
  }
}

/* 笑脸、哭脸 */
.monitor-face-smile,
.monitor-face-cry {
  width: 50px;
  height: 50px;
  display: inline-block;
  background-color: #fbd971;
  border-radius: 50%;
  position: relative;
}

.monitor-face-smile > span,
.monitor-face-smile:before,
.monitor-face-smile:after,
.monitor-face-cry > span,
.monitor-face-cry:before,
.monitor-face-cry:after {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  transform: rotate(225deg);
  border: 3px solid #f0c419;
  border-right-color: transparent !important;
  border-bottom-color: transparent !important;
  position: absolute;
  bottom: 8px;
  left: 11px;
}

.monitor-face-smile:before,
.monitor-face-smile:after,
.monitor-face-cry:before,
.monitor-face-cry:after {
  content: '';
  width: 6px;
  height: 6px;
  left: 8px;
  top: 14px;
  border-color: #f29c1f;
  transform: rotate(45deg);
}

.monitor-face-smile:after,
.monitor-face-cry:after {
  left: auto;
  right: 8px;
}

.monitor-face-cry > span {
  transform: rotate(45deg);
  bottom: -6px;
}

/* 圆形进度条组合 */
.monitor-progress-group {
  position: relative;
  display: inline-block;
}

.monitor-progress-group .el-progress:not(:first-child) {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  margin-top: -1px;
}

.monitor-progress-legends > div + div {
  margin-top: 8px;
}
</style>
