<!-- 角色编辑弹窗 -->
<template>
  <el-dialog
    width="800px"
    :visible="visible"
    :close-on-click-modal="false"
    :title="isUpdate ? '修改商户' : '添加商户'"
    @update:visible="updateVisible"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-row :gutter="20">
        <el-col :md="12">
          <el-form-item label="用户名:" prop="username" :required="!isUpdate" v-show="!isUpdate">
            <el-input
              clearable
              :maxlength="20"
              v-model="form.username"
              placeholder="请输入名称"

            />
          </el-form-item>
          <el-form-item label="密码:" prop="password" :required="!isUpdate">
            <el-input
              clearable
              :maxlength="20"
              v-model="form.password"
              placeholder="请输入密码"
            />
          </el-form-item>
          <el-form-item label="名称:" prop="name" required>
            <el-input
              clearable
              :maxlength="20"
              v-model="form.name"
              placeholder="请输入名称"
            />
          </el-form-item>
          <el-form-item label="状态:" required>
            <el-switch
              :active-value="true"
              :inactive-value="false"
              v-model="form.status"
            />
          </el-form-item>
          <el-form-item label="白名单:" required>
            <el-input
              clearable
              :maxlength="200"
              v-model="form.produceIps"
              placeholder="请输入名称"
            />
          </el-form-item>
        </el-col>
        <el-col :md="12">
          <el-form-item label="最大库存数（快）:" required>
            <el-input
              clearable
              :maxlength="200"
              type="number"
              v-model="form.maxCount"
              placeholder="请输入名称"
            />
          </el-form-item>
          <el-form-item label="重复产码:" required>
            <el-switch
              :active-value="true"
              :inactive-value="false"
              v-model="form.repetition"
            />
          </el-form-item>
          <el-form-item label="重复产码次数:" required v-show="form.repetition">
            <el-input
              clearable
              :maxlength="200"
              v-model="form.repetitionCount"
              placeholder="请输入名称"
            />
          </el-form-item>
          <el-form-item label="允许相同号码:" required>
            <el-switch
              :active-value="true"
              :inactive-value="false"
              v-model="form.repetitionNo"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer">
      <el-button @click="updateVisible(false)">取消</el-button>
      <el-button type="primary" @click="save" :loading="loading">
        保存
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {saveOrUpdate} from "@/api/tenant/supplier";

  const DEFAULT_FORM = {
    password: '',
    userId: "",
    tenantId: "",
    status: false,
    produceIps: "",
    name: "",
    id: "",
    maxCount: 400,
    repetition: false,
    repetitionCount: 5,
    repetitionNo: false,
    bankLong: 300
  };

  export default {
    name: 'RoleEdit',
    props: {
      // 弹窗是否打开
      visible: Boolean,
      // 修改回显的数据
      data: Object
    },
    data() {
      return {
        // 表单数据
        form: {...DEFAULT_FORM},
        // 表单验证规则
        rules: {},
        // 提交状态
        loading: false,
        // 是否是修改
        isUpdate: false,
        authorityAll: [],
        aisleAll: []
      };
    },
    created() {

    },
    methods: {
      /* 保存编辑 */
      save() {
        this.$refs['form'].validate((valid) => {
          if (!valid) {
            return false;
          }
          this.loading = true;
          saveOrUpdate(this.form).then((msg) => {
            this.loading = false;
            this.$message.success(msg);
            this.updateVisible(false);
            this.$emit('done');
          })
            .catch((e) => {
              this.loading = false;
              this.$message.error(e.message);
            });
        });
      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visible', value);
      }
    },
    watch: {
      visible(visible) {
        if (visible) {
          if (this.data) {
            this.$util.assignObject(this.form, this.data);
            this.isUpdate = true;
          } else {
            this.isUpdate = false;
          }
        } else {
          this.$refs['form'].clearValidate();
          this.form = {...DEFAULT_FORM};
        }
      }
    }
  };
</script>

<style scoped></style>
