<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 搜索表单 -->
      <tenant-search @search="reload"/>
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >
        <!-- 状态列 -->
        <template slot="status" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.status"
            disabled
          />
        </template>
        <!-- 状态列 -->
        <template slot="repetitionNo" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.repetitionNo"
            disabled
          />
        </template>
        <!-- 状态列 -->
        <template slot="repetition" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.repetition"
            disabled
          />
        </template>
        <!-- 表头工具栏 -->
        <template slot="toolbar">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-plus"
            class="ele-btn-icon"
            @click="openEdit()"
          >
            添加
          </el-button>
        </template>
        <!-- 操作列 -->
        <template slot="action" slot-scope="{ row }">
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openEdit(row)"
          >
            修改
          </el-link>
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openReadme(row)"
          >
            对接文档
          </el-link>
        </template>
      </ele-pro-table>
    </el-card>
    <tenant-edit :data="current" :visible.sync="showEdit" @done="reload"/>
  </div>
</template>

<script>
  import TenantSearch from './components/supplier-search';
  import TenantEdit from './components/supplier-edit';
  import {pageList} from '@/api/tenant/supplier';
  import {pageParam} from "@/utils/application";

  export default {
    name: 'SystemAuth',
    components: {
      TenantSearch,
      TenantEdit
    },
    data() {
      return {
        // 表格列配置
        columns: [
          {
            columnKey: 'selection',
            type: 'selection',
            width: 45,
            align: 'center'
          },
          {
            columnKey: 'index',
            type: 'index',
            width: 45,

            align: 'center',
            showOverflowTooltip: true
          },
          {
            prop: 'id',
            label: '供货商id',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 120
          },
          {
            prop: 'name',
            label: '用户名',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 120
          },
          {
            prop: 'secret',
            label: '密钥',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 150
          },
          {
            prop: 'status',
            label: '是否启用',
            align: 'center',
            sortable: 'custom',
            width: 120,
            resizable: false,
            slot: 'status'
          },
          {
            prop: 'produceIps',
            label: '白名单',
            align: 'center',
            sortable: 'custom',
            minWidth: 150,
          },
          {
            prop: 'maxCount',
            label: '最大库存（快）',
            align: 'center',
            sortable: 'custom',
            minWidth: 150,
          },
          {
            prop: 'repetitionNo',
            label: '允许重复号码',
            align: 'center',
            sortable: 'custom',
            minWidth: 150,
            slot: 'repetitionNo'
          },
          {
            prop: 'repetition',
            label: '重复产码',
            align: 'center',
            sortable: 'custom',
            minWidth: 150,
            slot: 'repetition'
          },
          {
            columnKey: 'action',
            label: '操作',
            width: 230,
            align: 'center',
            resizable: false,
            slot: 'action'
          }
        ],
        // 表格选中数据
        selection: [],
        // 当前编辑数据
        current: null,
        // 是否显示编辑弹窗
        showEdit: false,
        // 是否显示导入弹窗
        showAuth: false
      };
    },
    methods: {
      /* 表格数据源 */
      datasource({page, limit, where, order}) {
        const common = {
          name: where.name,
        };
        const range = []
        const params = pageParam(common, order, range)
        return pageList({...params, page, limit});
      },
      /* 刷新表格 */
      reload(where) {
        this.$refs.table.reload({page: 1, where: where});
      },
      /* 显示编辑 */
      openEdit(row) {
        if (row !== null && row !== undefined) {
          this.current = row;
        }
        this.showEdit = true;
      },
      openReadme(row) {
        this.$router.push({
          path: "/readme/supplier",
          query: {tenantId: row.tenantId, supplierId: row.id, secret: row.secret}
        });
      }
    }
  };
</script>

<style scoped></style>
