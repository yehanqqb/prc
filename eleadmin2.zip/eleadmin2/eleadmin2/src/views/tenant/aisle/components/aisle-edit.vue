<!-- 角色编辑弹窗 -->
<template>
  <el-dialog
    width="900px"
    :visible="visible"
    :close-on-click-modal="false"
    :title="isUpdate ? '修改通道' : '添加通道'"
    @update:visible="updateVisible"
  >
    <el-form ref="form" :model="form" :rules="rules" label-width="120px">
      <el-form-item label="是否启用:" prop="itenantAisle.status">
        <el-switch
          :active-value="true"
          :inactive-value="false"
          v-model="form.itenantAisle.status"
        />
      </el-form-item>
      <el-form-item label="屏蔽省份:" prop="itenantAisle.notProvince">
        <el-select @change="$forceUpdate()" v-model="form.itenantAisle.notProvince" multiple placeholder="请选择"
                   clearable class="ele-fluid el-item-style">
          <el-option
            v-for="item in province"
            :key="item"
            :label="item"
            :value="item">
          </el-option>
        </el-select>
      </el-form-item>
      <el-row :gutter="15">
        <el-col :lg="12">
          <el-table
            :data="form.aisleSupplier"
            style="width: 100%"
            max-height="250">
            <el-table-column
              prop="itenantSupplier.name"
              label="供货商"
              width="150">
            </el-table-column>
            <el-table-column
              prop="itenantAisleSupplier.radio"
              label="拉取比例"
              width="120">
            </el-table-column>
            <el-table-column
              label="操作"
              width="120">
              <template slot-scope="scope">
                <el-popconfirm
                  class="ele-action"
                  title="确定要移除吗？"
                  @confirm="deleteRow(scope.$index, form.aisleSupplier)"
                >
                  <el-link
                    type="danger"
                    slot="reference"
                    :underline="false"
                    icon="el-icon-edit"
                  >
                    移除
                  </el-link>
                </el-popconfirm>
                <el-button
                  @click="updateRow(scope.$index, form.aisleSupplier)"
                  type="text"
                  size="small">
                  修改
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-col>
        <el-col :lg="12">
          <el-form ref="form" :model="addSupplier" :rules="rules" label-width="120px">
            <el-form-item label="供货商:" prop="supplierId">
              <el-select @change="$forceUpdate()" v-model="addSupplier.supplierId" placeholder="请选择"
                         clearable class="ele-fluid el-item-style">
                <el-option
                  v-for="item in form.supplierAll"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="拉取比例:" prop="radio">
              <el-input v-model="addSupplier.radio"></el-input>
            </el-form-item>
          </el-form>
          <div style="margin-left: 35%">
            <el-button type="primary" @click="saveRadio" :loading="loading">
              保存
            </el-button>
          </div>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer">
      <el-button @click="updateVisible(false)">取消</el-button>
      <el-button type="primary" @click="save" :loading="loading">
        保存
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {deleteById, saveOrUpdate} from "@/api/tenant/aisle";
  import {PROVINCE} from "@/config/setting";
  import {saveRadioApi} from "@/api/tenant/aisle";

  const DEFAULT_FORM = {
    itenantAisle: {
      status: false,
      notProvince: []
    },
    isAisle: {},
    aisleSupplier: [],
    supplierAll: []
  };

  export default {
    name: 'aisleEdit',
    props: {
      // 弹窗是否打开
      visible: Boolean,
      // 修改回显的数据
      data: Object
    },
    components: {},
    data() {
      return {
        // 表单数据
        form: {...DEFAULT_FORM},
        // 表单验证规则
        rules: {},
        // 提交状态
        loading: false,
        // 是否是修改
        isUpdate: false,
        operatorsAll: [
          {id: 0, key: "DX", value: "电信"},
          {id: 1, key: "LT", value: "联通"},
          {id: 2, key: "YD", value: "移动"},
          {id: 3, key: "OTHER", value: "自由金额"},
        ],
        payTypeAll: [],
        money: [],
        province: PROVINCE,
        addSupplier: {
          supplierId: "",
          radio: "",
          id: "",
          aisleId: "",
        },
      };
    },
    created() {

    },
    methods: {
      /* 保存编辑 */
      save() {
        this.$refs['form'].validate((valid) => {
          if (!valid) {
            return false;
          }
          this.loading = true;
          let saveData = {
            notProvince: this.form.itenantAisle.notProvince,
            status: this.form.itenantAisle.status,
            id: this.form.itenantAisle.id
          };

          saveOrUpdate(saveData)
            .then((msg) => {
              this.loading = false;
              this.$message.success(msg);
              this.updateVisible(false);
              this.$emit('done');
            })
            .catch((e) => {
              this.loading = false;
              this.$message.error(e.message);
            });
        });
      },
      /* 更新visible */
      updateVisible(value) {
        this.$emit('update:visible', value);
      },
      deleteRow(index, row) {
        deleteById(row[index].itenantAisleSupplier.id).then(msg => {
          this.loading = false;
          this.$message.success(msg);
          this.updateVisible(false);
          this.$emit('done');
        })
      },
      updateRow(index, row) {
        this.addSupplier = {
          supplierId: row[index].itenantSupplier.id,
          radio: row[index].itenantAisleSupplier.radio,
          id: row[index].itenantAisleSupplier.id,
          aisleId: row[index].itenantAisleSupplier.aisleId,
        }
      },
      saveRadio() {
        this.addSupplier.aisleId = this.form.isAisle.id;
        saveRadioApi(this.addSupplier).then((msg) => {
          this.loading = false;
          this.$message.success(msg);
          this.updateVisible(false);
          this.$emit('done');
        })
          .catch((e) => {
            this.loading = false;
            this.$message.error(e.message);
          });
      },
      reload() {

      }
    },
    watch: {
      visible(visible) {
        if (visible) {
          if (this.data) {
            this.$util.assignObject(this.form, this.data);
            this.isUpdate = true;
          } else {
            this.isUpdate = false;
          }
        } else {
          this.$refs['form'].clearValidate();
          this.form = {...DEFAULT_FORM};
        }
      }
    }
  };
</script>

<style scoped></style>
