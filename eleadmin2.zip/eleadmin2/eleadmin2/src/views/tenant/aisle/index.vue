<template>
  <div class="ele-body">
    <el-card shadow="never">
      <!-- 数据表格 -->
      <ele-pro-table
        ref="table"
        :columns="columns"
        :datasource="datasource"
        :selection.sync="selection"
      >

        <template slot="status" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.itenantAisle.status"
            disabled
          />
        </template>
        <template slot="operators" slot-scope="{ row }">
          <el-select v-model="row.isAisle.operators" disabled multiple placeholder="请选择" @change="$forceUpdate()">
            <el-option
              v-for="item in operatorsAll"
              :key="item.id"
              :label="item.value"
              :value="item.id">
            </el-option>
          </el-select>
        </template>
        <template slot="payType" slot-scope="{ row }">
          <el-select v-model="row.isAisle.payType" disabled multiple placeholder="请选择" @change="$forceUpdate()">
            <el-option
              v-for="item in row.isAisle.payType"
              :key="item"
              :label="item"
              :value="item">
            </el-option>
          </el-select>
        </template>
        <template slot="money" slot-scope="{ row }">
          <el-select v-model="row.isAisle.rechargeMoney" disabled multiple placeholder="请选择" @change="$forceUpdate()">
            <el-option
              v-for="item in row.isAisle.rechargeMoney"
              :key="item"
              :label="item"
              :value="item">
            </el-option>
          </el-select>
        </template>
        <template slot="slow" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.isAisle.slow"
            disabled
          />
        </template>
        <template slot="fix" slot-scope="{ row }">
          <el-switch
            :active-value="true"
            :inactive-value="false"
            v-model="row.isAisle.fix"
            disabled
          />
        </template>
        <!-- 表头工具栏 -->
        <!-- 操作列 -->
        <template slot="action" slot-scope="{ row }">
          <el-link
            type="primary"
            :underline="false"
            icon="el-icon-edit"
            @click="openEdit(row)"
          >
            修改
          </el-link>
        </template>
      </ele-pro-table>
    </el-card>
    <aisle-edit ref="childEdit" :data="current" :visible.sync="showEdit" @done="reload"/>
  </div>
</template>

<script>
  import aisleEdit from './components/aisle-edit';
  import {getSupplier, pageList} from '@/api/tenant/aisle';
  import {pageParam} from "@/utils/application";
  import {pageList as pageSupplierList} from '@/api/tenant/supplier';



  export default {
    name: 'SystemAisle',
    components: {
      aisleEdit
    },
    data() {
      return {
        // 表格列配置
        columns: [
          {
            columnKey: 'selection',
            type: 'selection',
            width: 45,
            align: 'center'
          },
          {
            columnKey: 'index',
            type: 'index',
            width: 45,
            align: 'center',
            showOverflowTooltip: true
          },
          {
            prop: 'isAisle.name',
            label: '通道名称',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 150
          },
          {
            prop: 'iTenantAisle.status',
            label: '状态',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 120,
            slot: "status"
          },
          {
            prop: 'isAisle.operators',
            label: '运行商',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 150,
            slot: "operators"
          },
          {
            prop: 'isAisle.rechargeMoney',
            label: '金额',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 150,
            slot: "money"
          },
          {
            prop: 'isAisle.slow',
            label: '是否慢充',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 150,
            slot: "slow"
          },
          {
            prop: 'isAisle.payType',
            label: '支付编码',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 150,
            slot: "payType"
          },
          {
            prop: 'isAisle.fix',
            label: '任意金额',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 150,
            slot: "fix"
          },
          {
            prop: 'isAisle.createTime',
            label: '创建时间',
            sortable: 'custom',
            showOverflowTooltip: true,
            minWidth: 110,
            formatter: (row, column, cellValue) => {
              return this.$util.toDateString(cellValue);
            }
          },
          {
            columnKey: 'action',
            label: '操作',
            width: 230,
            align: 'center',
            resizable: false,
            slot: 'action'
          }
        ],
        // 表格选中数据
        selection: [],
        // 当前编辑数据
        current: null,
        // 是否显示编辑弹窗
        showEdit: false,
        // 是否显示导入弹窗
        showAuth: false,
        operatorsAll: [
          {id: 0, key: "DX", value: "电信"},
          {id: 1, key: "LT", value: "联通"},
          {id: 2, key: "YD", value: "移动"},
          {id: 3, key: "OTHER", value: "自由金额"},
        ],
      };
    },
    methods: {
      /* 表格数据源 */
      datasource({page, limit, where, order}) {
        const common = {
          name: where.name,
        };
        const range = []
        console.log(where.createTime);
        const params = pageParam(common, order, range)
        return pageList({...params, page, limit});
      },
      /* 刷新表格 */
      reload(where) {
        this.$refs.table.reload({page: 1, where: where});
      },
      /* 显示编辑 */
      openEdit(row) {
        getSupplier(row.isAisle.id).then(res => {
          row.aisleSupplier = res;
          let query = {};
          query['page'] = 1;
          query['limit'] = 1000;
          query['common'] = {};
          pageSupplierList(query).then(res2=>{
            row.supplierAll = res2.list;
            this.current = row;
            this.showEdit = true;
          })

        });
      }
    }
  };
</script>

<style scoped></style>
