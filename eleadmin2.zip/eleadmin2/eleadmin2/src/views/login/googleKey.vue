<template>
  <div :class="[
    'login-wrapper',
  ]">
    <div class="login-form ele-bg-white">
      <div class="login-binding-title">绑定谷歌身份验证</div>
      <div>
        谷歌身份验证是一款安装在移动设备上的动态口令工具，每30秒生成一个动态验证码，验证可用于安全验证
      </div>
      <div class="login-binding-step">第一步：下载谷歌身份验证APP</div>
      <div class="login-binding-picture">
        <img src="@/assets/gooleApp.png"/>
      </div>
      <div>无法扫码时，ios用户可进入App Store, 搜索"Authenticator"下载。</div>
      <div>Android用户可打开应用商店，搜索"身份验证器"下载</div>
      <div class="login-binding-step" style="margin-top: 30px;">第二步：在谷歌身份验证中添加密钥，获取授权码</div>
      <div>打开谷歌身份验证APP，扫描下方二维码或者手动输入下述密钥添加令牌。</div>
      <div class="login-binding-code">
        <div style="padding-right: 30px;">
          <div id="qrcode">
            <img :src="bindingInfo.googleQr" style="width: 70%">
          </div>
        </div>
        <div style="border-left: 1px solid #CECECE; padding-left: 30px;">
          <div>扫不了码？使用账号+密码获取</div>
          <div>密钥：{{ bindingInfo.googleKey }}</div>
          <el-button type="primary" size="small" style="margin: 5px 0;" v-clipboard:success="onCopy"
                     v-clipboard:copy="bindingInfo.googleKey" v-clipboard:error="onError">复制密钥
          </el-button>
        </div>
      </div>
      <div class="login-binding-tips">绑定成功后该密钥不再显示，请自行备份保存</div>
      <div class="login-binding-step">第三步：输入谷歌身份验证中验证码</div>
      <el-form :model="form" :rules="rules" ref="form">
        <el-form-item prop="name">
          <el-input v-model="form.code" @keyup.enter.native="submitForm('form')"></el-input>
        </el-form-item>
        <div style="text-align: center;">
          <el-button type="primary" @click="submitForm('form')">保 存</el-button>
        </div>
      </el-form>
    </div>
    <div class="login-copyright">
      copyright © 2021 eleadmin.com all rights reserved.
    </div>
  </div>
</template>

<script>
import {bindGoogle} from "@/api/login";

export default {
  name: 'Login',
  props: {
    googleInfo: Object,
  },
  data() {
    return {
      // 登录框方向, 0居中, 1居右, 2居左
      direction: 0,
      bindingInfo: {
        url: '',
        googleKey: '',
      },
      form: {
        code: '',
      },
      rules: {
        code: [
          {required: true, message: '请输入验证码', trigger: 'blur'},
        ],
      }
    };
  },
  methods: {
    getQR(data) {
      this.bindingInfo = data;
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          bindGoogle(this.form.code).then(res => {
            this.$message.success(res);
            this.$router.push(this.$route?.query?.from ?? '/').catch(() => {
            });
          });
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm() {
      this.$router.push('/login')
    },
    onCopy() {
      this.$message.success('复制成功');
    },
    onError() {
      this.$message.error('复制失败');
    },
  }
};
</script>

<style scoped>
/* 背景 */
.login-wrapper {
  padding: 50px 20px;
  position: relative;
  box-sizing: border-box;
  background-image: url('~@/assets/bg-login.jpg');
  background-repeat: no-repeat;
  background-size: cover;
  min-height: 100vh;
}

.login-wrapper:before {
  content: '';
  background-color: rgba(0, 0, 0, 0.2);
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
}

/* 卡片 */
.login-form {
  margin: 0 auto;
  width: 730px;
  max-width: 100%;
  padding: 25px 30px;
  position: relative;
  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.15);
  box-sizing: border-box;
  border-radius: 4px;
  z-index: 2;
}

.login-binding-title {
  font-size: 18px;
  padding-bottom: 10px;
  border-bottom: 1px solid #F0F0F0;
  margin-bottom: 20px;
}

.login-binding-step {
  font-weight: bold;
  margin: 10px 0;
}

.login-binding-picture {
  text-align: center;
}

.login-binding-code {
  display: flex;
  justify-content: center;
  margin-top: 15px;
  padding: 10px;
  align-items: center;
}

.login-binding-tips {
  color: red;
  text-align: center;
  margin-bottom: 30px;
}

.login-form-right .login-form {
  margin: 0 15% 0 auto;
}

.login-form-left .login-form {
  margin: 0 auto 0 15%;
}

.login-form h4 {
  text-align: center;
  margin: 0 0 25px 0;
}

.login-form > .el-form-item {
  margin-bottom: 25px;
}

/* 验证码 */
.login-input-group {
  display: flex;
  align-items: center;
}

.login-input-group ::v-deep .el-input {
  flex: 1;
}

.login-captcha {
  height: 38px;
  width: 102px;
  margin-left: 10px;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  text-align: center;
  cursor: pointer;
}

.login-captcha:hover {
  opacity: 0.75;
}

.login-btn {
  display: block;
  width: 100%;
}

/* 第三方登录图标 */
.login-oauth-icon {
  color: #fff;
  padding: 5px;
  margin: 0 10px;
  font-size: 18px;
  border-radius: 50%;
  cursor: pointer;
}

/* 底部版权 */
.login-copyright {
  color: #eee;
  padding-top: 20px;
  text-align: center;
  position: relative;
  z-index: 1;
}

/* 响应式 */
@media screen and (min-height: 550px) {
  .login-form {
    position: absolute;
    top: 30%;
    left: 50%;
    transform: translateX(-50%);
    margin-top: -220px;
  }

  .login-form-right .login-form,
  .login-form-left .login-form {
    left: auto;
    right: 15%;
    transform: translateX(0);
    margin: -220px auto auto auto;
  }

  .login-form-left .login-form {
    right: auto;
    left: 15%;
  }

  .login-copyright {
    position: absolute;
    bottom: 20px;
    right: 0;
    left: 0;
  }
}

@media screen and (max-width: 768px) {

  .login-form-right .login-form,
  .login-form-left .login-form {
    left: 50%;
    right: auto;
    transform: translateX(-50%);
    margin-right: auto;
  }
}
</style>
