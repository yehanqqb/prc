<template>
  <el-card>
    <h2>{{hr}}/supplier-api/api/supplier/trade/order
      <el-button>创建订单接口</el-button>
      <el-button>POST</el-button>
    </h2>

    <pre style="font-size: 18px;font-weight: 900">
      入参：{
         "supplierId":{{supplierId}},
         "orderId":"订单id",
         "operator":"DX(电信), LT(联通), YD(移动), OTHER(其他)",
         "money":"金额，不含小数点",
         "productNo":"号码",
         "notifyUrl":"通知地址"
         "slow":true（慢充）/false （快充） 布尔值不带引号
         "sign":"加密",
         "tenantId":{{tenantId}},
         "ext":{
            "inquireProvince":是否查询运营商。花费订单请填true。其他填false 布尔值不带引号
          }

      出参：{
        code: "200/500(200为成功，其他为失败)"
        data:"",
        message:"提示"
      }
    </pre>
    <h2> {{hr}}/supplier-api/api/supplier/query/{orderId}
      <el-button>查询订单接口</el-button>
      <el-button>POST</el-button>
    </h2>

    <pre style="font-size: 18px;font-weight: 900">
      入参：PATH:orderId

      出参：{
        code: "200/500(200为成功，其他为失败)"
        data:{
          payStatus:"-1/0 -1为失败，0为成功 1 等待中 支付状态",
          finishStatus:"-1/0 -1为失败，0为成功 1 等待中 到账状态"
        },
        message:"提示"
      }
      <p style="color: red"> 这个接口不是实时的，有1-3s延迟 请不要用这个接口去判断是否成功，一定要以通知为准 。当支付状态与到账状态不一致的时候为 返销</p>
    </pre>
    <pre style="font-size: 18px;font-weight: 900">
      sign加密方法:
        除sign外的其他参数按字母表顺序排序，值相加.不带参数名,再进行md5加密(不含"+")
      MD5(ext+money+notifyUrl+operator+orderId+productNo+slow+supplierId+tenantId+<span
      style="color: red">{{secret}}</span>)
    </pre>
    <pre style="font-size: 18px;font-weight: 900">
      回调参数:
       {
        orderId:"",
        money:"",
        status:"0（0为成功，其他都为失败）"，
        sign:"",
        remark:"",
        paymentNo:"流水单号",
        finishTime:"到账时间"
      }
    </pre>
  </el-card>
</template>

<script>
  export default {
    name: "merchant",
    data() {
      return {
        tenantId: "",
        supplierId: "",
        secret: "",
        hr: ""
      }
    },
    created() {
      this.tenantId = this.$route.query.tenantId
      this.supplierId = this.$route.query.supplierId
      this.secret = this.$route.query.secret
      this.hr = window.location.protocol + "//" + window.location.host + "/4a1ecd4cc23c4d228d43b256df519a8e"

    }
  }

</script>

<style scoped>

</style>
