<template>
  <el-card>
    <h2>{{hr}}/merchant-api/api/merchant/trade/order
      <el-button>创建订单接口</el-button>
      <el-button>POST</el-button>
    </h2>

    <pre style="font-size: 18px;font-weight: 900">
      入参：{
        "orderId":"来源订单id",
        "money":"金额，不含小数点",
        "sign":"加密",
        "notifyUrl":"通知地址",
        "merchantId":{{merchantId}},
        "tenantId":{{tenantId}},
        "fix":"true/false 是否是任意金额 true：是，false: 否",
        "userIp":"用户支付ip，非必填",
        "payType":"支付编码"
      }

      出参：{
        code: "200/500(200为成功，其他为失败)"
        data:"收银台地址（直接跳转）",
        message:"提示"
      }
    </pre>

    <h2>{{hr}}/merchant-api/api/merchant/query/{orderId}
      <el-button>查询订单接口</el-button>
      <el-button>POST</el-button>
    </h2>

    <pre style="font-size: 18px;font-weight: 900">
      入参：PATH:orderId

      出参：{
        code: "200/500(200为成功，其他为失败)"
        data:"0/-1 （0为成功。-1为失败）",
        message:"提示"
      }
            <p style="color: red"> 这个接口不是实时的，有1-3s延迟 请不要用这个接口去判断是否成功，一定要以通知为准 </p>

    </pre>
    <pre style="font-size: 18px;font-weight: 900">
      <h2> sign加密方法:</h2>
        除sign外的其他参数按字母表顺序排序，值相加（不带参数名,再进行md5加密(不含"+")
        MD5(fix+merchantId+money+notifyUrl+orderId+payType+tenantId+userIp+<span style="color: red">{{secret}}</span>)
    </pre>
    <pre style="font-size: 18px;font-weight: 900">
      回调参数:
       {
        orderId:"",
        money:"",
        status:"0（0为成功，其他都为失败）"，
        sign:"",
        remark:""
      }
    </pre>
  </el-card>
</template>

<script>
  export default {
    name: "merchant",
    data() {
      return {
        tenantId: "",
        merchantId: "",
        secret: "",
        hr: ""
      }
    },
    created() {
      this.tenantId = this.$route.query.tenantId
      this.merchantId = this.$route.query.merchantId
      this.secret = this.$route.query.secret
      this.hr = window.location.protocol + "//" + window.location.host+"/4a1ecd4cc23c4d228d43b256df519a8e"
    }
  }

</script>

<style scoped>

</style>
