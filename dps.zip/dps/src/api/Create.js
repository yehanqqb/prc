import axios from '../utils/request'

export async function getPayTypeByTenantId (tenantId) {
  console.log(process.env.VUE_APP_API_BASE_URL);
  const res = await axios.get('/pay/type/' + tenantId)
  if (res.data.code === 200) {
    return res.data.data
  }
  return Promise.reject(new Error(res.data.msg))
}

export async function treadPay (data) {
  const res = await axios.post('/trade/order', data)
  if (res.data.code === 200) {
    return res.data.data
  }
  return Promise.reject(new Error(res.data.msg))
}