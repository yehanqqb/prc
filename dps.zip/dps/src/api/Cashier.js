import axios from '../utils/request'

export async function tradePay(tradeId, userKey) {
    console.log(process.env.VUE_APP_API_BASE_URL);
    const res = await axios.post('/trade/pay/' + tradeId + "?userKey=" + userKey)
    return res.data
}


export async function tradeBefore(tradeId, userKey) {
    console.log(process.env.VUE_APP_API_BASE_URL);
    const res = await axios.post('/trade/before/' + tradeId + "?userKey=" + userKey)
    return res.data
}

export async function tradeAfter(tradeId, userKey) {
    console.log(process.env.VUE_APP_API_BASE_URL);
    const res = await axios.post('/trade/after/' + tradeId + "?userKey=" + userKey)
    return res.data
}

export async function awsCode() {
    console.log(process.env.VUE_APP_API_BASE_URL);
    const res = await axios.get('/code/init')
    return res.data
}

export async function awsCode2() {
    console.log(process.env.VUE_APP_API_BASE_URL);
    const res = await axios.get('/code/init2')
    return res.data
}

export async function awsCodeCheck(tradeId, slider, xd5) {
    console.log(process.env.VUE_APP_API_BASE_URL);
    const res = await axios.post('/code/checkAfter/' + tradeId + '?slider=' + slider + "&xd5=" + xd5)
    return res.data
}

export async function awsCodeCheck2(tradeId, slider, xd5) {
    console.log(process.env.VUE_APP_API_BASE_URL);
    const res = await axios.post('/code/checkAfter2/' + tradeId + '?slider=' + slider + "&xd5=" + xd5)
    return res.data
}