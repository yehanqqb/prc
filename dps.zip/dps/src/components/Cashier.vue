<template>
    <div>
        <Modal v-model="modal1" title="order is expires" @on-ok="ok" @on-cancel="cancel"><p>订单已过期，请勿支付</p></Modal>
        <Progress :percent="counter" hide-info/>
        <br>
        <br>
        <br>
        <Row>
            <Col span="20" offset="2">倒计时：<span style="color: red;font-size: 26px">{{counter}}</span>S</Col>
        </Row>

    </div>
</template>
<script>
    import {Decrypt, isNull} from "@/utils/application";
    import {tradePay} from "@/api/Cashier";
    import afterH5 from "@/components/after/H5pay";

    export default {
        name: 'cashier',
        data() {
            return {
                modal1: false,
                payType: "",
                expiresTime: "",
                counter: 0,
                timer: "",
                before: false,
                userKey: "",
            }
        },
        created() {
            const trade = Decrypt(this.$route.query.tradeId)
            const tradeArray = trade.split(",");
            this.expiresTime = tradeArray[1];
            this.payType = tradeArray[2];

            if (!isNull(this.$route.query.before)) {
                this.before = this.$route.query.before;
                this.userKey = this.$route.query.userKey;
            }
            if (!this.before) {
                let existBefore = this.$router.options.routes.filter(route => route.name === tradeArray[2])
                if (!isNull(existBefore)) {
                    let pathBefore = {
                        name: existBefore[0].name,
                        path: existBefore[0].path,
                        query: {
                            tradeId: this.$route.query.tradeId
                        }
                    }
                    this.$router.push(pathBefore)
                    return;
                }

            }

            const counter = ((tradeArray[1] - new Date().getTime()) / 1000).toFixed(0);
            this.counter = Number(counter)
            if (counter <= 0) {
                this.modal1 = true
                return;
            }
            this.startTime();
        },
        methods: {
            ok() {
                window.location.href = "http://www.baidu.com"
            },
            cancel() {
                window.location.href = "http://www.baidu.com"
            },
            handleData() {
                if (this.counter === -1) {
                    const counter = (this.expiresTime - new Date().getTime()) / 1000;
                    this.counter = counter
                    if (counter <= 0) {
                        this.modal1 = true
                        return;
                    }
                    clearInterval(this.timer)
                } else {
                    this.HandlePayApi();
                }
            },
            startTime() {
                //定时器
                this.timer = setInterval(() => {
                    this.counter = this.counter - 1;
                    if (this.counter <= 0) {
                        this.modal1 = true
                    }
                }, 1000)
                this.handleData();
            },
            HandlePayApi() {
                tradePay(this.$route.query.tradeId, this.userKey).then(res => {
                    if (res.code === 200 && res.data.status === true) {
                        let existBefore = this.$router.options.routes.filter(route => route.name === "after_" + this.payType)
                        if (!isNull(existBefore)) {
                            let pathBefore = {
                                name: existBefore[0].name,
                                path: existBefore[0].path,
                                params: {
                                    toPay: res.data.payUrl,
                                    outTime: this.expiresTime,
                                    productNo: res.data.productNo,
                                    tradeId: this.$route.query.tradeId
                                }
                            }
                            this.$router.push(pathBefore)
                        } else {
                            let pathBefore = {
                                path: '/after/toH5',
                                name: 'after_h5',
                                params: {
                                    toPay: res.data.payUrl,
                                    outTime: this.expiresTime
                                }
                            }
                            this.$router.push(pathBefore)
                        }
                        clearInterval(this.timer)
                    } else {
                        this.sleep(1000);
                        this.handleData();
                    }
                }).catch(() => {
                    this.sleep(1000);
                    this.handleData();
                })
            },
            sleep(d) {
                for (let t = Date.now(); Date.now() - t <= d;) ;
            }
        }
    }
</script>
