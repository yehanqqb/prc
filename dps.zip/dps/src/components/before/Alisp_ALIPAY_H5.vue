<template>
    <Row>
        <Col span="20" offset="2">
            <Button @click="review" type="primary">返回</Button>
        </Col>
    </Row>
</template>

<script>

    export default {
        name: "ALIPAY_H5",
        methods: {
            review() {
                this.$router.push({
                    path: '/cashier',
                    name: 'cashier',
                    query: {
                        tradeId: this.$route.query.tradeId,
                        before: true
                    }
                })
            }
        }
    }
</script>

<style scoped>

</style>
