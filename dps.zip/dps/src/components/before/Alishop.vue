<template>
    <Row>
        <Col span="20" offset="2">
            <Carousel autoplay v-model="value2" loop autoplay-speed="3000">
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/alishop_1.png"></div>
                </CarouselItem>
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/alishop_2.jpg"></div>
                </CarouselItem>
            </Carousel>
        </Col>
        <Col span="20" offset="2">
            <Button @click="review" type="primary">我知道了</Button>
        </Col>
    </Row>
</template>
<script>
    export default {
        name: "Dypp.vue",
        data() {
            return {
                value2: 0
            }
        },
        methods: {
            review() {
                this.$router.push({
                    path: '/cashier',
                    name: 'cashier',
                    query: {
                        tradeId: this.$route.query.tradeId,
                        before: true
                    }
                })
            }
        }
    }
</script>

<style scoped>
    .img {
        width: 100%;
        height: 50%;
    }
</style>
