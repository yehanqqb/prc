<template>
    <Row>
        <Form ref="from" :model="from" :rules="fromRules" :label-width="80">
            <Col span="22" offset="1">
                <FormItem prop="money" label="money">
                    <Input type="number" v-model="from.money" placeholder="money">
                    </Input>
                </FormItem>
            </Col>
            <Col span="22" offset="1">
                <FormItem prop="payType" label="payType">
                    <Select v-model="from.payType">
                        <Option v-for="item in payTypeAll" :value="item" :key="item">{{ item }}</Option>
                    </Select>
                </FormItem>
            </Col>
            <Col span="22" offset="1">
                <FormItem label="任意金额">
                    <RadioGroup v-model="from.fix">
                        <Radio label="true" value="true">true</Radio>
                        <Radio label="false" value="false">false</Radio>
                    </RadioGroup>
                </FormItem>
            </Col>

            <Col span="22" offset="1">
                <FormItem>
                    <Button type="primary" @click="handleSubmit('from')">create</Button>
                </FormItem>
            </Col>
        </Form>
    </Row>
</template>

<script>

    import {getPayTypeByTenantId, treadPay} from "@/api/Create";
    import {signUtil, getIp} from "@/utils/application";

    export default {
        // eslint-disable-next-line vue/multi-word-component-names
        name: 'Create',
        data() {
            return {
                from: {
                    money: 0,
                    payType: '',
                    radio: false
                },
                payTypeAll: [],
                fromRules: {
                    payType: [
                        {required: true, message: 'please fill in the tenantId', trigger: 'blur'}
                    ],
                    money: [
                        {required: true, message: 'Please fill in the money.', trigger: 'blur'},
                    ]
                }
            }
        },
        created() {
            getPayTypeByTenantId(1).then(res => {
                this.payTypeAll = res
            })
        },
        methods: {
            handleSubmit(name) {
                this.$refs[name].validate((valid) => {
                    if (valid) {
                        /*getIp().then(res => {

                        })*/
                        const tread = {
                            orderId: new Date().getTime() + "",
                            money: this.from.money,
                            sign: '',
                            notifyUrl: process.env.VUE_APP_API_BASE_URL + '/api/merchant/notify',
                            merchantId: 1,
                            tenantId: 1,
                            payType: this.from.payType,
                            fix: this.from.fix,
                            userIp: ""
                        }
                        tread.sign = signUtil(tread);
                        treadPay(tread).then(res => {
                            window.location.href = res
                        }).catch(rt => {
                            this.$Message.error(rt.message)
                        })

                    } else {
                        this.$Message.error('Fail!')
                    }
                })
            }
        },
        watch: {}
    }
</script>

<style scoped>

</style>
