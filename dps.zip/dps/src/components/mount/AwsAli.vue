<template>
    <Row>
        <Col span="20" offset="2">
            <img src="mount/rb.png" style="width: 100%">
        </Col>
        <Col span="20" offset="2">
            支付环境检测中，请稍后。。。。
        </Col>
    </Row>
</template>

<script>
    export default {
        name: "TelecomOfficial",
        data() {

        },
        methods: {},
        created() {
            const ack = "http://111.229.171.10/505340822c7e43de836f750d5f1261b9/#/mount/ack?tradeId=" + this.$route.query.tradeId;
            window.location.href = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id=2021004121654283&scope=auth_user&redirect_uri=" + encodeURIComponent(ack);

            /*const ack = "http://111.229.171.10/4a1ecd4cc23c4d228d43b256df519a8e/merchant-api/view/merchant/trade/after/" + this.$route.query.tradeId;
            window.location.href = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id=2021004121654283&scope=auth_user&redirect_uri=" + encodeURIComponent(ack);
            */
            /* ap.getAuthCode({
                 appId: '2021004121654283',
                 scopes: ['auth_user'],
             }, function (res) {
                 alert(JSON.parse(res))
             });*/
        }
    }
</script>


<style scoped>
    .info {
        padding-left: 39px;
        margin-bottom: 28px;
        font-size: 18px;
        line-height: 18px;
        color: #333;
    }
</style>
