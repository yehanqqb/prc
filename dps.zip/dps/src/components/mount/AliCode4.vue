<template>
    <Row>
        <Col span="20" offset="2">
            为了您的安全请滑动滑块 <span style="color: red">耐心等待10s</span>
        </Col>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <Col span="20" offset="2">
            <div id="nocaptcha"></div>
        </Col>
    </Row>
</template>
<script>
    import {awsCodeCheck2, tradeBefore} from "@/api/Cashier";

    export default {
        name: "alicode4",
        data() {
            return {
                value2: 0
            }
        },
        created() {
            const that = this;
            const r = JSON.parse(decodeURIComponent(this.$route.query.url));
            const k = {
                "renderTo": "#nocaptcha",
                "appkey": r.NCAPPKEY,
                "token": r.NCTOKENSTR,
                "scene": "register",
                "reportUrl": "//reg.taobao.com:443/member/reg/fast/unify_process.do/_____tmd_____/report?" + r.SECDATA,
                "language": "cn",
                "upLang": {"cn": {"BXMARK": "请刷新页面重试"}},
                success: function (e) {
                    console.log(e)
                },
                replaceCallback: function (e) {
                    awsCodeCheck2(that.$route.query.tradeId, encodeURIComponent(JSON.stringify(e.data)), r.SECDATA).then(re => {
                        if (re.data) {
                            that.review();
                        } else {
                            that.$Message.error("验证失败，请重试");
                            window.location.reload();
                        }
                    })
                }
            }
            // eslint-disable-next-line no-undef
            AWSC.use("nc", (function (e, t) {
                t.init(k)
            }), {
                timeout: 3e4
            })

        },
        methods: {
            review() {
                tradeBefore(this.$route.query.tradeId, this.$route.query.smsCode).then(res => {
                    if (res.data.code === 0) {
                        this.$router.push({
                            path: '/mount/click',
                            name: 'click',
                            params: {
                                url: res.data.retUrl,
                            }
                        })
                    } else if (res.data.code === 3) {
                        window.location.reload();
                    } else {
                        this.$Message.error("验证码错误请重试");
                        this.tj = true;
                    }
                })
            }
        }
    }
</script>

<style scoped>
    .img {
        width: 100%;
        height: 50%;
    }
</style>
