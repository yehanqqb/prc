<template>
    <a type="primary" :href="hres" style="  text-decoration: underline;font-size: 25px">点击支付</a>
</template>

<script>
    export default {
        name: "ClickUrl",
        data() {
            return{
                hres:""
            }
        },
        created() {
            this.hres = this.$route.params.url;
        }
    }
</script>

<style scoped>

</style>
