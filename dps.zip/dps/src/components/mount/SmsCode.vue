<template>
    <div>
        <img v-show="sms" style="width: 80%" src="mount/sms.jpg">
        <label for="code" v-show="sms">
            <ul class="security-code-container">
                <li class="field-wrap" :class="{'on':seat==index}" v-for="(item, index) in list" :key="index"
                    @click="onClick(index)">
                    <i class="char-field">{{value[index] || placeholder}}</i>
                </li>
            </ul>
        </label>
        <p style="color: red">提交之后请耐心等待10s。。。</p>
        <input ref="input"
               class="input-code"
               @keyup="keyup($event)"
               @keydown="keydown($event)"
               v-model="value"
               id="code"
               type="number"
               :maxlength="number"
               @touchstart="keyup($event)"
               @touchend="keydown($event)"
               v-show="sms"
        />
        <Button type="primary" v-show="sms" @click="handleSubmit()">提交</Button>
        <div v-show="!sms">
            <a type="primary" :href="uri" style="  text-decoration: underline;font-size: 25px">点击支付</a>
        </div>
    </div>

</template>
<script>
    import {tradeBefore} from "@/api/Cashier";

    export default {
        name: 'SecurityCode',
        props: {
            number: {
                type: Number,
                default: 6
            },
            placeholder: {
                type: String,
                default: '-'
            }
        },
        data() {
            return {
                value: '',
                seat: -1,
                list: '',
                tj: false,
                sms: true,
                uri: "",
            }
        },
        created() {
            /*const that = this;*/
            /*tradeAfter(this.$route.query.tradeId, this.$route.query.auth_code).then(res => {
                if (res.data.code === 0) {
                    that.uri = res.data.retUrl;
                    that.sms = false;
                    this.$router.push({
                        path: '/mount/click',
                        name: 'click',
                        params: {
                            url: res.data.retUrl,
                        }
                    })
                }
            });*/
            this.list = new Array(this.number)
        },
        methods: {

            hideKeyboard() {
                // 输入完成隐藏键盘
                document.activeElement.blur() // ios隐藏键盘
                this.$refs.input.blur() // android隐藏键盘
                this.tj = true;
            },
            keydown(e) {//当按下按键时
                console.log(e)
                //alert(JSON.stringify(e))
            },
            keyup() { //按键松开时运行
                this.seat += 1
                this.$refs.input.value = this.value
                if (this.value.length >= this.number) {
                    this.hideKeyboard()
                    this.seat = this.number
                }
            },
            handleSubmit() { //返回信息
                const that = this;
                this.tj = false;
                if (that.value.length < 6) {
                    this.$Message.error("验证码错误请重试");
                    return;
                }
                tradeBefore(this.$route.query.tradeId, this.value).then(res => {
                    if (res.data.code === 0) {
                        that.uri = res.data.retUrl;
                        that.sms = false;
                        this.$router.push({
                            path: '/mount/click',
                            name: 'click',
                            params: {
                                url: res.data.retUrl,
                            }
                        })
                    } else if (res.data.code === 4) {
                        this.$router.push({
                            path: '/mount/aliCode4',
                            name: 'aliCode4',
                            query: {
                                tradeId: this.$route.query.tradeId,
                                url: encodeURIComponent(res.data.url)
                            }
                        })
                    } else if (res.data.code === 3) {
                        this.$router.push({
                            path: '/mount/aliCode3',
                            name: 'aliCode3',
                            query: {
                                tradeId: this.$route.query.tradeId,
                                smsCode: this.value
                            }
                        })
                    } else {
                        this.$Message.error("验证码错误请重试");
                        this.tj = true;
                    }
                })
            },
            onClean() { //清除
                this.value = ''
                this.seat = -1
            },
            onClick(index) {//点击
                this.seat = index
            }
        }
    }
</script>
<style scoped lang="less">
    .security-code-container {
        margin: 0;
        padding: 20px 0;
        display: flex;
        justify-content: center;

        .field-wrap {
            list-style: none;
            display: block;
            border: 1px solid #eee;
            height: 45px;
            width: 45px;
            font-size: 18px;
            text-align: center;
            overflow: hidden;
            background-color: #fff;
            margin-right: 5px;

            .char-field {
                font-style: normal;
            }

            &.on {
                border: 1px solid #0E88EF;
            }
        }
    }

    .input-code {
        width: 100%;
        height: 30px;
        position: absolute;
        left: -999999999999px;
        opacity: 0;
        z-index: -1;
    }

    .clean {
        width: 100%;
        box-sizing: border-box;
        text-align: right;
        color: #0E88EF;
        font-size: 12px;
        padding: 0 10px;
    }
</style>
