<template>
    <Row>
        <Col span="20" offset="2">
            <p style="color: red;font-size: 26px;font-weight: 900;text-align: center">请在支付宝消息内完成支付</p>
        </Col>
        <br>
        <br>
        <br>
        <br>
        <Col span="20" offset="2">
            <img style="width: 100%" src="mount/bank2.jpg">
        </Col>
    </Row>
</template>

<script>
    export default {
        name: "BankMessage.vue"
    }
</script>

<style scoped>

</style>
