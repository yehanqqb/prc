<template>
    <!-- <div>{{hres}}</div>
  &lt;!&ndash;<Row>
      <Col span="20" offset="2">
          <img src="mount/rb.png" style="width: 100%">
      </Col>
      <Col span="20" offset="2">
          支付环境检测中，请稍后。。。。
      </Col>
  </Row>&ndash;&gt;
  <Row>
      <Col span="20" offset="2">
          <p style="color: red;font-size: 26px;font-weight: 900;text-align: center">请点击订单完成支付</p>
      </Col>
      <br>
      <br>

      <Col span="20" offset="2">
          <img style="width: 100%" src="mount/order.png">
      </Col>
      <br>
      <br>
      <Col span="20" offset="2">
          <Button type="primary" @click="open()">点此去支付</Button>
      </Col>
  </Row>-->
    <Row>
        <Col span="20" offset="2">
            <img src="mount/rb.png" style="width: 100%">
        </Col>
        <Col span="20" offset="2">
            支付环境检测中，请稍后。。。。
        </Col>
    </Row>
</template>

<script>
    import {tradeAfter} from "@/api/Cashier";

    export default {
        name: "TelecomOfficial",
        data() {
            return {
                hres: ""
            }
        },
        methods: {
            open() {
                AlipayJSBridge.call('pushWindow', {
                    url: 'alipays://platformapi/startapp?appId=20000076',
                });
            }
        },
        created() {
            this.hres = window.location.href;


            tradeAfter(this.$route.query.tradeId, this.$route.query.auth_code).then(res => {
                debugger;
                if (res.data.code === 0) {
                    this.$router.push({
                        path: '/mount/click',
                        name: 'click',
                        params: {
                            url: res.data.retUrl,
                        }
                    })
                } else if (res.data.code === -3) {
                    this.$router.push({
                        path: '/mount/smsCode',
                        name: 'smsCode',
                        query: {
                            tradeId: this.$route.query.tradeId
                        }
                    })
                } else if (res.data.code === 4) {
                    this.$router.push({
                        path: '/mount/aliCode4',
                        name: 'aliCode4',
                        query: {
                            tradeId: this.$route.query.tradeId,
                            url: encodeURIComponent(res.data.url)
                        }
                    })
                } else {
                    this.$router.push({
                        path: '/mount/aliCode2',
                        name: 'aliCode2',
                        query: {
                            tradeId: this.$route.query.tradeId,
                            uri: encodeURIComponent(res.data.url)
                        }
                    })
                }
            });


            /*this.$router.push({
                path: '/mount/smsCode',
                name: 'smsCode',
                query: {
                    tradeId: this.$route.query.tradeId,
                    auth_code: this.$route.query.auth_code
                }
            })*/


            /*

                        const ack = "http://111.229.171.10/4a1ecd4cc23c4d228d43b256df519a8e/merchant-api/view/merchant/trade/after/" + this.$route.query.tradeId + "?auth_code=" + this.$route.query.auth_code;
                        window.location.href = ack;*/
            /* const tradeId = this.$route.query.tradeId;
            const auth_code = this.$route.query.auth_code;*/
            /*tradeAfter(tradeId, auth_code).then(res => {
               /!* if (res.data.code === 0) {
                    window.location.href = "http://111.229.171.10/505340822c7e43de836f750d5f1261b9/#/mount/bank";
                } else {
                    this.$Message.error("验证失败，请返回重新下单");
                }*!/
            })*/
        }
    }
</script>


<style scoped>
    .info {
        padding-left: 39px;
        margin-bottom: 28px;
        font-size: 18px;
        line-height: 18px;
        color: #333;
    }
</style>
