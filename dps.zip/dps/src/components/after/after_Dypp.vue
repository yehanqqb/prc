<template>
    <Row>
        <Modal
                v-model="modal1"
                title="一定要在抖音充值"
                @on-ok="ok"
                @on-cancel="cancel">
            <div class="demo-carousel"><h1 style="color: red">一定要在抖音钱包充值！否则不到账</h1></div>
        </Modal>
        <Col span="20" offset="2">
            <p>倒计时：<span style="color: red;font-size: 32px">{{outTime}}</span>s</p>
        </Col>
        <Col span="20" offset="2">
            <p>充值号码：<span style="color: red;font-size: 32px">{{productNo}}</span></p>
        </Col>
        <Col span="20" offset="2">
            <Button @click="toOpen" type="primary">复制并跳转</Button>
        </Col>
        <Col span="20" offset="2">
            <Carousel autoplay v-model="value2" loop>
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/dyapp_1.png"></div>
                </CarouselItem>
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/dyapp_2.png"></div>
                </CarouselItem>
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/dyapp_3.png"></div>
                </CarouselItem>
            </Carousel>
        </Col>
    </Row>
</template>

<script>
    export default {
        name: "Dypp.vue",
        data() {
            return {
                value2: 0,
                outTime: 0,
                productNo: "",
                modal1: false
            }
        },
        methods: {
            toOpen() {
                this.modal1 = true
            },
            ok() {
                this.toPay();
            },
            cancel() {
                this.toPay();
            },
            toPay() {
                const copyContent = this.productNo
                const input = document.createElement("input"); // 直接构建input
                input.value = copyContent; // 设置内容
                document.body.appendChild(input); // 添加临时实例
                input.select(); // 选择实例内容
                document.execCommand("Copy"); // 执行复制
                document.body.removeChild(input); // 删除临时实例
                this.$Message.info("已复制号码-" + this.productNo);
                window.location.href = this.$route.params.toPay;
            }
        },
        created() {
            this.productNo = this.$route.params.productNo;
            setInterval(() => {
                const counter = parseInt((this.$route.params.outTime - new Date().getTime()) / 1000);
                this.outTime = counter
                if (counter <= 0) {
                    window.location.href = "http://wwww.baidu.com"
                }
            }, 1000)
        }
    }
</script>

<style scoped>
    .img {
        width: 100%;
        height: 50%;
    }
</style>
