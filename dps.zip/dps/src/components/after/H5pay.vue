<template>
    <Row>
        <Col span="20" offset="2">
            <p>倒计时：<span style="color: red;font-size: 32px">{{outTime}}</span>s</p>
        </Col>
        <Col span="20" offset="2">
            <Button type="primary" @click="toPay()">去支付</Button>
        </Col>
    </Row>
</template>

<script>
    export default {
        name: "H5pay",
        data() {
            return {
                outTime: 0,

            }
        },
        methods: {
            toPay() {
                window.location.href = this.$route.params.toPay;
            }
        },
        created() {
            setInterval(() => {
                const counter = parseInt((this.$route.params.outTime - new Date().getTime()) / 1000);
                this.outTime = counter
                if (counter <= 0) {
                    window.location.href = "http://wwww.baidu.com"
                }
            }, 1000)
        }
    }
</script>

<style scoped>

</style>
