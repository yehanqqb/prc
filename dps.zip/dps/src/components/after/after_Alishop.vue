<template>

    <Row>
        <Modal
                v-model="modal1"
                title="一定要点收货"
                @on-ok="ok"
                @on-cancel="cancel">
            <div class="demo-carousel"><img class="img" src="pay/alishop_2.jpg"></div>
        </Modal>
        <Col span="20" offset="2">
            <p>倒计时：<span style="color: red;font-size: 32px">{{outTime}}</span>s</p>
        </Col>
        <Col span="20" offset="2">
            <Form :model="formItem" :label-width="80">
                <FormItem label="手机号">
                    <Input v-model="formItem.userKey" placeholder="输入您的淘宝登录手机号"></Input>
                </FormItem>
                <FormItem>
                    <Button type="primary" @click="before">确认</Button>
                </FormItem>
            </Form>
        </Col>
        <Col span="20" offset="2" autoplay-speed="3000">
            <Carousel autoplay v-model="value2" loop>
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/alishop_1.png"></div>
                </CarouselItem>
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/alishop_2.jpg"></div>
                </CarouselItem>
            </Carousel>
        </Col>
    </Row>
</template>

<script>
    import {tradeBefore} from "@/api/Cashier";

    export default {
        name: "H5pay",
        data() {
            return {
                modal1: false,
                outTime: 0,
                formItem: {
                    userKey: ""
                },
                value2: 0
            }
        },
        methods: {
            ok() {
                this.toPay();
            },
            cancel() {
                this.toPay();
            },
            toPay() {
                window.location.href = this.$route.params.toPay;
            },
            before() {
                const phoneReg = /^[1][3,4,5,7,8][0-9]{9}$/;
                const value = this.formItem.userKey;
                if (!phoneReg.test(value)) {
                    this.$Message.error("请输入正确的手机号");
                    return false;
                }
                tradeBefore(this.$route.params.tradeId, value).then(res => {
                    if (res.data.code === 0) {
                        this.modal1 = true;
                    } else {
                        this.$Message.error("请输入正确的手机号");
                        return false;
                    }
                })
            }
        },
        created() {
            setInterval(() => {
                const counter = parseInt((this.$route.params.outTime - new Date().getTime()) / 1000);
                this.outTime = counter
                if (counter <= 0) {
                    window.location.href = "http://wwww.baidu.com"
                }
            }, 1000)
        }
    }
</script>

<style scoped>
    .img {
        width: 100%;
        height: 50%;
    }
</style>
