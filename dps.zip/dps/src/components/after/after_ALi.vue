<template>

    <Row>
        <Modal
                v-model="modal1"
                title="一定要点收货"
                @on-ok="ok"
                @on-cancel="cancel">
            <div class="demo-carousel"><img class="img" src="pay/alishop_6.jpg"></div>
        </Modal>
        <Col span="20" offset="2">a
            <p>倒计时：<span style="color: red;font-size: 32px">{{outTime}}</span>s</p>
        </Col>
        <Col span="20" offset="2">
            <Button type="primary" @click="openH5()">去支付</Button>
        </Col>
        <Col span="20" offset="2" autoplay-speed="3000">
            <Carousel autoplay v-model="value2" loop>
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/alishop_5.jpg"></div>
                </CarouselItem>
                <CarouselItem>
                    <div class="demo-carousel"><img class="img" src="pay/alishop_6.jpg"></div>
                </CarouselItem>
            </Carousel>
        </Col>
    </Row>
</template>

<script>
    import {tradeBefore} from "@/api/Cashier";

    export default {
        name: "H5pay",
        data() {
            return {
                modal1: false,
                outTime: 0,
                formItem: {
                    userKey: ""
                },
                value2: 0
            }
        },
        methods: {
            openH5() {
                this.modal1 = true;
            },
            ok() {
                this.toPay();
            },
            cancel() {
                this.toPay();
            },
            toPay() {
                window.location.href = this.$route.params.toPay;
            }
        },
        created() {
            setInterval(() => {
                const counter = parseInt((this.$route.params.outTime - new Date().getTime()) / 1000);
                this.outTime = counter
                if (counter <= 0) {
                    window.location.href = "http://wwww.baidu.com"
                }
            }, 1000)
        }
    }
</script>

<style scoped>
    .img {
        width: 100%;
        height: 50%;
    }
</style>
