<template>
    <div class="reharge-box">
        <div class="reharge-detail-wrap" style="margin-bottom: 20px;">
            <div class="header-recharge-info">
                <div class="header-pay-success">
                    <img src="voucher/mobile.png"/>
                </div>
                <div class="header-success">已到账</div>
            </div>
        </div>
        <div class="reharge-detail-wrap" style="padding: 30px 20px;">
            <div class="recharge-item">
                <div class="recharge-content-label">订单号码：</div>
                <div class="recharge-content-value">{{ currentInfo.orderNum || '--' }}</div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">充值号码：</div>
                <div class="recharge-content-value">{{ currentInfo.phone || '--' }}</div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">充值金额：</div>
                <div class="recharge-content-value">{{ currentInfo.money || '--' }}.00</div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">支付金额：</div>
                <div class="recharge-content-value">{{ currentInfo.money || '--' }}.00</div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">创建时间：</div>
                <div class="recharge-content-value">{{ currentInfo.time }}</div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        name: "TelecomOfficial",
        data() {
            return {
                currentInfo: {}
            }
        },
        methods: {},
        created() {
            const queryParams = this.$router.currentRoute.query;
            this.currentInfo = queryParams.money ? queryParams : {
                money: 100,
                phone: '13919306191',
                time: '2022-05-14 16:49:39',
                orderNum: '2342354364366646676546',
                oper: "电信"
            }
        }
    }
</script>
<style scoped>
    .reharge-box {
        box-sizing: border-box;
        color: #0C0C0C;
        background-color: #F6F6F6;
        height: 100vh;
        margin-top: 40px;
        width: 25%;
        margin-left: 40%;
        border: 1px solid red;
    }

    .header-recharge-info {
        height: 160px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .header-pay-success {
        margin-bottom: 10px;
    }

    .header-success {
        font-size: 18px;
        font-weight: bold;
        padding-bottom: 10px;
    }

    .recharge-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
    }

    .recharge-content-label {
        font-size: 14px;
        width: 100px;
        color: #7D7D7D;
    }

    .recharge-content-value {
        font-size: 14px;
        flex: 1;
        color: #d4b970;
        font-weight: 500;
    }

    .reharge-detail-wrap {
        padding: 0 10px;
        background-color: #ffffff;
    }

</style>
