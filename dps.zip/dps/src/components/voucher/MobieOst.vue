<template>
    <div>
        <img src="https://pay.it.10086.cn/payprod-format/img/icon_logo1.png">
        <span style="padding-top:-20px;font-size: 20px;color: #0389d8; margin-left: 14px;">中国移动收银台</span>
        <br>
        <br>
        <div style="margin-left:25%;width: 50%;height: 300px;
    border: 1px solid #d7d7d7;
    margin: 0 auto;
    padding: 0 25px 26px 26px;
    box-sizing: border-box;">
            <div style="height: 40px;
  background: #b9e4fd;
  padding-left: 39px;
  line-height: 40px;
  font-size: 18px;
  color: #333;text-align: left">
                订单详情
                <br>
                <br>
                <div class="info">订单日期：{{currentInfo.time}}</div>
                <div class="info">订单号：{{currentInfo.orderNum}}</div>
                <div class="info">商品名称：为{{currentInfo.phone}}充值{{currentInfo.money}}元</div>
                <div class="info">订单状态：
                    <span style="color: green;font-size: 22px">支付成功</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "TelecomOfficial",
        data() {
            return {
                currentInfo: {}
            }
        },
        methods: {},
        created() {
            const queryParams = this.$router.currentRoute.query;
            this.currentInfo = queryParams.money ? queryParams : {
                money: 100,
                phone: '13919306191',
                time: '2022-05-14 16:49:39',
                orderNum: '2342354364366646676546',
                oper: "电信"
            }
        }
    }
</script>


<style scoped>
    .info {
        padding-left: 39px;
        margin-bottom: 28px;
        font-size: 18px;
        line-height: 18px;
        color: #333;
    }
</style>
