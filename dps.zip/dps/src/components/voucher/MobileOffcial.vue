<script>
    export default {
        name: "MobileOffcial",
        data() {
            return {
                currentInfo: {},

            }
        },
        methods: {},
        created() {
            const queryParams = this.$router.currentRoute.query;
            this.currentInfo = {
                address: queryParams.oper || '云南',
                phone: queryParams.phone || '1197287512',
                money: queryParams.money || '99.8',
                time: queryParams.time || '99.8',
                order: queryParams.orderNum || '0000000000000000000000000000000',
            }
        }
    }
</script>
<template>
    <div class="finishedPay-box">
        <div class="finishedPay-title">
            <div class="finishedPay-logo">
                <img src="voucher/mobile/logo.png"/>
            </div>
            <div class="finishedPay-title-content">
                <div style="font-weight: bolder;font-size: 15px;">{{currentInfo.address}}移动和生活</div>
                <img src="voucher/mobile/gift.png" style="margin-top: 3px;"/>
            </div>
            <div style="display: flex;flex-direction: row; justify-content: flex-end;">
                <img src="voucher/mobile/giftbtn.png"/>
            </div>
            <div style="display: flex;flex-direction: column;height: 100%; justify-content: flex-start;">
                <img src="voucher/mobile/syslogo.png"/>
            </div>
        </div>
        <div class="finishedPay-actions">
            <div>
                <img src="voucher/mobile/syslogo.png"/>
            </div>
            <div>
                <img src="voucher/mobile/login.png"/>
            </div>
        </div>
        <div class="finishedPay-content">
            <div class="content-img" style="height: 80px;">
                <img src="voucher/mobile/paysuccess.png" style="margin-top: 20px;"/>
            </div>
            <div class="content-img" style="padding: 0 60px; color: #888888; text-align: center; font-weight: normal;">
                目前充值量大，若成功支付预计到账时间为10分钟请关注到账短信
            </div>
            <div class="finishedPay-detail">
                <div>充值号码：<span style="color: red;">{{currentInfo.phone}}</span></div>
                <div>充值金额：<span style="color: red;">{{currentInfo.money}}元</span></div>
                <div>充值订单流水号：</div>
                <div>{{currentInfo.order}}</div>
            </div>
            <div class="content-img" style="height: 50px;">
                <img src="voucher/mobile/backbtn.png"/>
            </div>
            <div style="position: fixed;right: 0;top: 110px;">
                <img src="voucher/mobile/aipeople.png"/>
            </div>
        </div>
        <div class="finishedPay-content" style="height: 30px"></div>
        <div class="finishedPay-content" style="padding: 8px;">
            <img src="voucher/mobile/recommend.png"/>
            <br>
            <img src="voucher/mobile/img_1.png" style="width: 100%"/>
        </div>
    </div>
</template>

<style scoped>
    .finishedPay-box {
        width: 25%;
        margin-left: 40%;
        height: 100vh;
        background-color: #F1F1F3;
        font-weight: bolder;
        font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", STHeiti, "Microsoft Yahei", Tahoma, Simsun, sans-serif;
    }

    .finishedPay-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 60px;
    }

    .finishedPay-logo {
        margin: 0 10px;
        display: flex;
    }

    .finishedPay-title-content {
        flex: 1;
    }

    .finishedPay-actions {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 45px;
        background-color: #FFFFFF;
        padding: 0 5px;
    }

    .finishedPay-content {
        margin: 8px 7px 0 7px;
        background-color: #FFFFFF;
        border-radius: 4px;
    }

    .content-img {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .finishedPay-detail {
        font-weight: normal;
        padding: 0 20px 0 30px;
        margin-top: 15px;
        margin-bottom: 15px;
        color: #888888;
    }
</style>
