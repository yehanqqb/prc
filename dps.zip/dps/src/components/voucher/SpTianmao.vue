<script>
    import vip from '../../assets/vip.png';
    import phone from '../../assets/phone.png';
    import arrowLeft from '../../assets/arrowLeft.png';
    import arrowRight from '../../assets/arrowRight.png';
    import arrowDown from '../../assets/arrowDown.png';
    import detail from '../../assets/detail.png';
    import detail2 from '../../assets/img.png';
    import detail3 from '../../assets/50.png';
    import detail4 from '../../assets/30.png';
    import detail50 from '../../assets/img_8.png';
    import detail6200 from '../../assets/img_9.png';
    import detail7100 from '../../assets/img_10.png';
    import yd200 from '../../assets/yd200.png';
    import yd100 from '../../assets/yd100.png';
    import yd50 from '../../assets/yd50.png';
    import yd30 from '../../assets/yd30.png';

    export default {
        name: "MobileOffcial",
        data() {
            return {
                currentInfo: {},
                imgUrl: "",
                vip: vip,
                phone: phone,
                arrowLeft: arrowLeft,
                arrowRight: arrowRight,
                arrowDown: arrowDown,
                detail: detail,
                detail2: detail2,
                detail3: detail3,
                detail4: detail4,
                detail50: detail50,
                detail6200: detail6200,
                detail7100: detail7100,
                yd200: yd200,
                yd100: yd100,
                yd50: yd50,
                yd30: yd30,
            }
        },
        methods: {},
        created() {
            const queryParams = this.$router.currentRoute.query;
            this.currentInfo = {
                oper: queryParams.oper || '云南',
                phone: queryParams.phone || '1197287512',
                money: queryParams.money || '99.8',
                time: queryParams.time || '99.8',
                orderNum: queryParams.orderNum || '0000000000000000000000000000000',
            }
            let imgUrl = '';
            if (queryParams.oper === '电信') {
                imgUrl = queryParams.money === '100' ? detail : (queryParams.money === '50' ? detail3 : (queryParams.money === '30' ? detail4 : detail2))
            } else if (queryParams.oper === '联通') {
                imgUrl = queryParams.money === '100' ? detail7100 : (queryParams.money === '50' ? detail50 : (queryParams.money === '30' ? detail6200 : detail6200))
            } else {
                imgUrl = queryParams.money === '100' ? yd100 : (queryParams.money === '50' ? yd50 : (queryParams.money === '30' ? yd30 : yd200))
            }
            this.imgUrl = imgUrl;
        }
    }


</script>

<template>
    <div class="reharge-box">
        <div style="display: flex; flex-direction: row;">
            <img :src="arrowLeft" style="width: 20px; height: 20px; padding: 20px 8px 0 8px;"/>
            <div class="reharge-detail-title" style="flex: 0.9; text-align: center">账单详情</div>
        </div>
        <div class="reharge-detail-wrap">
            <div class="header-recharge-info">
                <div class="header-pay-success">
                    <img :src="phone" style="width: 55px; height: auto"/>
                </div>
                <div class="header-shop" style="margin-bottom: 15px;">中国{{ currentInfo.oper }}官方旗舰店</div>
                <div class="header-money">{{ `-${currentInfo.money}.00` || '--' }}</div>
                <div class="header-shop">交易成功</div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">付款方式</div>
                <div class="recharge-content-value">余额
                    <img :src="arrowRight" style="width: 13px; height: auto"/>
                </div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">支付宝积分</div>
                <div class="recharge-content-value" style="display: flex; justify-content: flex-end;">
                    <div
                            style="background-color: #F5F5F9;border-radius: 20px;height: 25px;width: 200px; line-height: 25px; padding: 0 5px;">
                        <img :src="vip" style="width: 15px; height: auto"/>
                        立即领取35积分（已翻5倍）
                    </div>
                </div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">商品说明</div>
                <div class="recharge-content-value">手机充值</div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">充值号码</div>
                <div class="recharge-content-value">{{
                    currentInfo.phone.replace(/^(.{3})(.*)(.{4})$/, '$1 $2 $3') || '--'
                    }}
                </div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">交易对象</div>
                <div class="recharge-content-value">中国{{ currentInfo.oper }}官方旗舰店</div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">创建时间</div>
                <div class="recharge-content-value">{{ currentInfo.time }}</div>
            </div>
            <div class="recharge-item">
                <div class="recharge-content-label">交易单号</div>
                <div class="recharge-content-value">{{ currentInfo.orderNum }}</div>
            </div>
            <div style="margin-bottom: 10px;">
                <div style="color: #CCCCCC; text-align: center;width: 100%;font-size: 14px;">更多
                    <img :src="arrowDown" style="width: 13px; height: auto"/>
                </div>
            </div>
        </div>
        <div class="reharge-detail-wrap"
             v-if="currentInfo.money==='100' || currentInfo.money=== '200' || currentInfo.money=== '50'">
            <div style="font-size: 14px;">
                <div style="margin-bottom: 10px;color: #4F5151;">
                    服务详情
                </div>
                <div>
                    <div style="display: flex;">
                        <img
                                :src="imgUrl"
                                style="width: 80px; height: auto"/>

                        <div class="header-money-one">中国{{ currentInfo.oper }}官方旗舰店 全国手机充值{{ currentInfo.money }}元 {{
                            currentInfo.oper }} 话费充值快速充值
                        </div>
                        <img :src="arrowRight" style="width: 13px; height: 13px;margin-top: 8px;"/>

                    </div>
                </div>
            </div>
        </div>
        <div class="reharge-detail-wrap">
            <div class="recharge-titips-item" style="border-bottom: 1px solid #eeecec;">
                <div style="color: #4F5151;">
                    账单分类
                </div>
                <div>
                    <span style="color: #7D7D7D;margin-right: 5px;">充值缴费</span>
                    <img :src="arrowRight" style="width: 13px; height: auto"/>
                </div>
            </div>
            <div class="recharge-titips-item">
                <div>
                    标注和备注
                </div>
                <div>
                    <span style="color: #7D7D7D;margin-right: 5px;">添加</span>
                    <img :src="arrowRight" style="width: 13px; height: auto"/>
                </div>
            </div>
        </div>
        <div class="footer">
            话费一般30分钟内到账，月初为高峰期，可能会有延迟到账的情况，若迟迟未到账可点击 “联系商家”咨询
        </div>
    </div>
</template>

<style scoped>
    .reharge-box {
        box-sizing: border-box;
        color: #0C0C0C;
        background-color: #F6F6F6;
        height: 100vh;
        margin-top: 40px;
        width: 30%;
        margin-left: 35%;
        border: 1px solid red;
    }

    .header-recharge-info {
        height: 150px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .header-money {
        font-size: 22px;
        letter-spacing: 2px;
        margin-bottom: 10px;
        font-weight: 400;
    }

    .header-money-one {
        font-size: 14px;
        margin-bottom: 10px;
        line-height: 30px;
        font-weight: 550;
        color: #4F5151;
        padding-left: 10px;
    }

    .header-shop {
        font-size: 14px;
        color: #656565;
    }

    .recharge-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 22px;
    }

    .recharge-content-label {
        font-size: 14px;
        width: 80px;
        color: #7D7D7D;
    }

    .header-pay-success {
        margin-bottom: 20px;
        margin-top: -25px;
    }

    .recharge-content-value {
        font-size: 14px;
        flex: 1;
        text-align: right;
        color: #4F5151;
    }

    .recharge-titips-box {
        color: #7D7D7D;
    }

    .recharge-titips-item {
        padding: 13px 0;
        display: flex;
        font-size: 14px;
        justify-content: space-between;
    }

    .reharge-detail-wrap {
        margin: 8px 8px 8px 8px;
        padding: 10px;
        background-color: #ffffff;
        border-radius: 8px;
    }

    .reharge-detail-title {
        padding: 20px 0 25px 0;
        text-align: center;
        font-size: 16px;
    }

    .footer {
        position: absolute;
        bottom: 0px;
        background-color: #ffffff;
        height: 38px;
        font-size: 12px;
        color: #eac3ad;
        padding: 8px;
    }
</style>
