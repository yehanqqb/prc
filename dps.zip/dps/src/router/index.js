import Vue from 'vue'
import Router from 'vue-router'
import create from '@/components/Create'
import cashier from '@/components/Cashier'
import alipay_h5 from '@/components/before/Alisp_ALIPAY_H5'
import afterH5 from '@/components/after/H5pay'
import TelecomOfficial from '@/components/voucher/TelecomOfficial'
import MobileOfficial from '@/components/voucher/MobileOffcial'
import aliSp from '@/components/after/after_AliSp'
import MobileOst from '@/components/voucher/MobieOst'
import Dyapp from '@/components/before/Dypp'
import afterDyapp from '@/components/after/after_Dypp'
import alishop from '@/components/before/Alishop'
import afterAlishop from '@/components/after/after_Alishop'
import afterAli from '@/components/after/after_ALi'
import aliCode from '@/components/before/AliCode'
import aliCode2 from '@/components/mount/AliCode2'

import aliCode3 from '@/components/mount/AliCode3'
import aliCode4 from '@/components/mount/AliCode4'

import mountAwsBefore from '@/components/mount/AwsAli'
import mountAwsAfter from '@/components/mount/AwsAck'

import sp from '@/components/voucher/SpTianmao'
import bankYou from '@/components/mount/BankMessage'
import smsCode from '@/components/mount/SmsCode'
import click from '@/components/mount/ClickUrl'
Vue.use(Router)

export default new Router({
    routes: [
        {
            path: '/create',
            name: 'create',
            component: create
        },
        {
            path: '/cashier',
            name: 'cashier',
            component: cashier
        },
        {
            path: '/before/alipay_h5',
            name: 'ALIPAY_H5',
            component: alipay_h5
        },
        {
            path: '/before/dyapp',
            name: 'dyapp',
            component: Dyapp
        },
        {
            path: '/before/fastDyapp',
            name: 'fastDyapp',
            component: Dyapp
        },
        {
            path: '/before/Alishop',
            name: 'Alishop',
            component: alishop
        },
        /*{
            path: '/before/aliCode',
            name: 'AliCode',
            component: aliCode
        },
        {
            path: '/before/Alic2',
            name: 'Alic2',
            component: aliCode
        },*/
        {
            path: '/after/toH5',
            name: 'after_h5',
            component: afterH5
        },
        {
            path: '/after/aliSp',
            name: 'after_AliSp',
            component: aliSp
        },

        {
            path: '/after/ALi',
            name: 'after_ALi',
            component: afterAli
        },
        {
            path: '/after/dyapp',
            name: 'after_dyapp',
            component: afterDyapp
        },
        {
            path: '/after/fastDyapp',
            name: 'after_fastDyapp',
            component: afterDyapp
        },
        {
            path: '/after/Alishop',
            name: 'after_Alishop',
            component: afterAlishop
        },
        {
            path: '/vouter/telecomOfficial',
            name: 'TelecomOfficial',
            component: TelecomOfficial
        },
        {
            path: '/vouter/mobileOfficial',
            name: 'MobileOfficial',
            component: MobileOfficial
        },
        {
            path: '/vouter/mobileOst',
            name: 'MobileOst',
            component: MobileOst
        },
        {
            path: '/vouter/sp',
            name: 'sp',
            component: sp
        },
        {
            path: '/mount/ali',
            name: 'aliaws',
            component: mountAwsBefore
        },
        {
            path: '/mount/ack',
            name: 'aliawsAck',
            component: mountAwsAfter
        },
        {
            path: '/mount/bank',
            name: 'mountBank',
            component: bankYou
        },
        {
            path: '/mount/smsCode',
            name: 'smsCode',
            component: smsCode
        },
        {
            path: '/mount/aliCode2',
            name: 'aliCode2',
            component: aliCode2
        },
        {
            path: '/mount/aliCode3',
            name: 'aliCode3',
            component: aliCode3
        },
        {
            path: '/mount/aliCode4',
            name: 'aliCode4',
            component: aliCode4
        },
        {
            path: '/mount/click',
            name: 'click',
            component: click
        }
    ]
})
