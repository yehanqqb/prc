/**
 * axios实例
 */
import axios from 'axios'

const service = axios.create({
  baseURL: process.env.VUE_APP_API_BASE_URL,
})

/* 添加请求拦截器 */
service.interceptors.request.use(
  (config) => {
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

/* 添加响应拦截器 */
service.interceptors.response.use((res) => {
    return res
  },
  (error) => {
    if (error.response.status === 500) {
      return error.response.data
    }
  }
)

export default service
