import md5 from 'js-md5';
import CryptoJS from 'crypto-js'
import cashier from "@/components/Cashier";
import axios from "@/utils/request";


export function signUtil(data) {
    const signStr = data.fix + data.merchantId + data.money + data.notifyUrl + data.orderId + data.payType + data.tenantId + data.userIp + 'df2636bc2ad1478caa6ed48cb70364f5'
    return md5(signStr)
}

const key = CryptoJS.enc.Utf8.parse("0123456789ABHAEQ");  //十六位十六进制数作为密钥
const iv = CryptoJS.enc.Utf8.parse('DYgjCEIMVrj2W9xN');   //十六位十六进制数作为密钥偏移量

//解密方法
export function Decrypt(word) {
    let encryptedHexStr = CryptoJS.enc.Hex.parse(word);
    let srcs = CryptoJS.enc.Base64.stringify(encryptedHexStr);
    let decrypt = CryptoJS.AES.decrypt(srcs, key, {iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7});
    let decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
    return decryptedStr.toString();
}

//加密方法
export function Encrypt(word) {
    let srcs = CryptoJS.enc.Utf8.parse(word);
    let encrypted = CryptoJS.AES.encrypt(srcs, key, {iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7});
    return encrypted.ciphertext.toString();

}

export function isNull(val) {
    return val === null || val === undefined || val === "" || val.length === 0
}


export async function getIp() {
    const apiUrl = 'https://api.ipify.org?format=json';
    const res = await axios.get(apiUrl)
    return res.data.ip
}
