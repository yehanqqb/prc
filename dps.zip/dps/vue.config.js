const {defineConfig} = require('@vue/cli-service')
module.exports = defineConfig({
  publicPath:"/505340822c7e43de836f750d5f1261b9",
  transpileDependencies: true,
  lintOnSave: false,
  productionSourceMap: true,
  configureWebpack: {
    externals: {
      AWSC: 'AWSC',
      AlipayJSBridge: 'AlipayJSBridge'
    },
  },
  css: {
    loaderOptions: {
      sass: {
        sassOptions: {
          outputStyle: 'expanded'
        }
      }
    }
  }
})
